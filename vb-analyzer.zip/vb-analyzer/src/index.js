const path = require('path');

const Logger = require('./utils/logger');
const ProjectScanner = require('./scanner/project-scanner');
const StaticAnalyzer = require('./analyzers/static-analyzer');
const PlatformAnalyzer = require('./analyzers/platform-analyzer');
const DependencyAnalyzer = require('./analyzers/dependency-analyzer');
const DatabaseAnalyzer = require('./analyzers/database-analyzer');
const RuleEngine = require('./rules/rule-engine');
const ImpactClassifier = require('./classifier/impact-classifier');
const JsonReporter = require('./report/json-reporter');

/**
 * VB.NET Pre-IR/BR Migration Analyzer — Main Orchestrator
 * 
 * Coordinates all analysis phases in the correct order:
 * 
 *   1. Project Scanner       → Project inventory
 *   2. Rule Engine            → Load detection rules
 *   3. Static Analyzer        → Pattern-based code analysis
 *   4. Platform Analyzer      → Windows/Linux dependencies
 *   5. Dependency Analyzer    → DLLs, NuGet, frameworks
 *   6. Database Analyzer      → DB connections, SQL patterns
 *   7. Impact Classifier      → IR/BR impact classification
 *   8. JSON Reporter          → Structured report output
 */
class Analyzer {
  constructor(options = {}) {
    this.logger = new Logger({
      verbose: options.verbose || false,
      silent: options.silent || false
    });
    this.options = options;
  }

  /**
   * Run the complete analysis pipeline
   * @param {string} projectPath - Absolute path to the VB.NET project root
   * @returns {Object} The final analysis report
   */
  async analyze(projectPath) {
    const startTime = Date.now();
    const resolvedPath = path.resolve(projectPath);

    this.logger.section('VB.NET Pre-IR/BR Migration Analyzer');
    this.logger.info(`Project: ${resolvedPath}`);
    this.logger.info(`Target: ${this.options.target || 'java-spring-angular'}`);
    this.logger.info(`Platform: ${this.options.targetPlatform || 'linux'}`);
    this.logger.info('');

    // ── Phase 1: Project Scanner ─────────────────────────────────────
    const scanner = new ProjectScanner(this.logger);
    const inventory = scanner.scan(resolvedPath);

    // ── Phase 6: Rule Engine (load rules before analysis) ────────────
    const ruleEngine = new RuleEngine(this.logger);
    const rules = ruleEngine.loadRules(this.options.rulesDir || null);

    // ── Phase 2: Static Analysis ─────────────────────────────────────
    const staticAnalyzer = new StaticAnalyzer(this.logger);
    const staticIssues = staticAnalyzer.analyze(inventory, rules);

    // ── Phase 3: Platform Dependency Analysis ────────────────────────
    const platformAnalyzer = new PlatformAnalyzer(this.logger);
    const platformIssues = platformAnalyzer.analyze(inventory);

    // ── Phase 4: Dependency Analysis ─────────────────────────────────
    const dependencyAnalyzer = new DependencyAnalyzer(this.logger);
    const dependencyIssues = dependencyAnalyzer.analyze(inventory);

    // ── Phase 4b: Database Analysis ──────────────────────────────────
    const databaseAnalyzer = new DatabaseAnalyzer(this.logger);
    const databaseIssues = databaseAnalyzer.analyze(inventory);

    // ── Combine all issues ───────────────────────────────────────────
    const allIssues = [
      ...staticIssues,
      ...platformIssues,
      ...dependencyIssues,
      ...databaseIssues
    ];

    // Enrich issues with rule metadata
    for (let i = 0; i < allIssues.length; i++) {
      allIssues[i] = ruleEngine.enrichIssue(allIssues[i]);
    }

    // Deduplicate across analyzers (same ruleId + file + line)
    const deduped = this._deduplicateIssues(allIssues);

    // ── Phase 8: IR/BR Impact Classification ─────────────────────────
    const classifier = new ImpactClassifier(this.logger);
    const classificationResult = classifier.classify(deduped, inventory);

    // ── Report Generation ────────────────────────────────────────────
    const reporter = new JsonReporter(this.logger);
    const report = reporter.generate(inventory, classificationResult, {
      target: this.options.target || 'java-spring-angular',
      targetPlatform: this.options.targetPlatform || 'linux'
    });

    // Add timing
    report.analysisDurationMs = Date.now() - startTime;

    // Write report to file if output path specified
    if (this.options.output) {
      const outputPath = path.resolve(this.options.output);
      reporter.writeToFile(report, outputPath);
    }

    // Print final summary
    this._printFinalSummary(report);

    return report;
  }

  /**
   * Deduplicate issues that may have been detected by multiple analyzers
   */
  _deduplicateIssues(issues) {
    const seen = new Map();

    for (const issue of issues) {
      const key = `${issue.ruleId}|${issue.file}|${issue.line || 'null'}`;
      
      if (seen.has(key)) {
        // Merge sources
        const existing = seen.get(key);
        const newSources = issue.source || [];
        for (const src of newSources) {
          if (!existing.source.includes(src)) {
            existing.source.push(src);
          }
        }
        // Keep higher confidence
        if (issue.confidence > existing.confidence) {
          existing.confidence = issue.confidence;
        }
      } else {
        seen.set(key, { ...issue });
      }
    }

    return Array.from(seen.values());
  }

  /**
   * Print the final summary to the console
   */
  _printFinalSummary(report) {
    const chalk = require('chalk');
    
    console.log('');
    console.log(chalk.bold.white('═'.repeat(60)));
    console.log(chalk.bold.white('  ANALYSIS COMPLETE'));
    console.log(chalk.bold.white('═'.repeat(60)));
    console.log('');

    const s = report.summary;

    // Readiness indicator
    if (report.irGenerationReady) {
      console.log(chalk.green.bold('  ✔ IR GENERATION: READY'));
    } else {
      console.log(chalk.red.bold(`  ✖ IR GENERATION: BLOCKED (${s.irBlockers} blocker(s))`));
    }

    if (report.brGenerationReady) {
      console.log(chalk.green.bold('  ✔ BR GENERATION: READY'));
    } else {
      console.log(chalk.red.bold(`  ✖ BR GENERATION: BLOCKED (${s.brBlockers} blocker(s))`));
    }

    console.log('');

    // Overall readiness
    const readiness = report.readinessAssessment.overallReadiness;
    const readinessColors = {
      'READY': chalk.green,
      'CONDITIONAL': chalk.yellow,
      'AT_RISK': chalk.hex('#FF8C00'),
      'BLOCKED': chalk.red
    };
    const colorFn = readinessColors[readiness] || chalk.white;
    console.log(colorFn.bold(`  Overall Readiness: ${readiness}`));
    console.log('');

    // Issue counts
    console.log(chalk.white(`  Total Issues: ${s.totalIssues}`));
    if (s.critical > 0) console.log(chalk.red(`    Critical: ${s.critical}`));
    if (s.high > 0) console.log(chalk.hex('#FF8C00')(`    High:     ${s.high}`));
    if (s.medium > 0) console.log(chalk.yellow(`    Medium:   ${s.medium}`));
    if (s.low > 0) console.log(chalk.gray(`    Low:      ${s.low}`));

    console.log('');
    console.log(chalk.white(`  IR Blockers:         ${s.irBlockers}`));
    console.log(chalk.white(`  BR Blockers:         ${s.brBlockers}`));
    console.log(chalk.white(`  IR Warnings:         ${s.irWarnings}`));
    console.log(chalk.white(`  BR Warnings:         ${s.brWarnings}`));
    console.log(chalk.white(`  Migration Warnings:  ${s.migrationWarnings}`));
    console.log(chalk.white(`  No Direct Impact:    ${s.noDirectImpact}`));
    
    console.log('');
    console.log(chalk.gray(`  Analysis completed in ${report.analysisDurationMs}ms`));

    // Recommendations
    if (report.readinessAssessment.recommendations.length > 0) {
      console.log('');
      console.log(chalk.bold.cyan('  Recommendations:'));
      for (const rec of report.readinessAssessment.recommendations) {
        console.log(chalk.cyan(`    → ${rec}`));
      }
    }

    console.log('');
    console.log(chalk.bold.white('═'.repeat(60)));
  }
}

module.exports = Analyzer;
