const RuleEngine = require('../rules/rule-engine');

/**
 * Phase 8: IR/BR Impact Classifier
 * 
 * Every issue gets an impact classification that determines whether it:
 * - Blocks IR generation
 * - Blocks BR generation
 * - Is a migration warning
 * - Has no direct impact
 * 
 * This classifier refines the default impact from rule definitions
 * based on project context and issue evidence.
 */
class ImpactClassifier {
  constructor(logger) {
    this.logger = logger;
  }

  /**
   * Classify all issues with refined IR/BR impact
   * @param {Object[]} issues - Array of detected issues
   * @param {Object} inventory - Project inventory
   * @returns {Object[]} Issues with refined impactType and confidence
   */
  classify(issues, inventory) {
    this.logger.section('Phase 8: IR/BR Impact Classification');

    for (const issue of issues) {
      // Apply contextual refinement rules
      this._refineImpact(issue, inventory);
      
      // Ensure confidence is bounded
      issue.confidence = Math.max(0, Math.min(1, issue.confidence));
    }

    // Sort by impact priority, then severity, then confidence (desc)
    issues.sort((a, b) => {
      const impactDiff = RuleEngine.impactPriority(a.impactType) - RuleEngine.impactPriority(b.impactType);
      if (impactDiff !== 0) return impactDiff;
      const sevDiff = RuleEngine.severityPriority(a.severity) - RuleEngine.severityPriority(b.severity);
      if (sevDiff !== 0) return sevDiff;
      return b.confidence - a.confidence;
    });

    // Assign unique issue IDs
    for (let i = 0; i < issues.length; i++) {
      issues[i].id = `ISSUE-${String(i + 1).padStart(3, '0')}`;
    }

    // Calculate summary
    const summary = this._calculateSummary(issues);

    this.logger.subsection('Impact Summary');
    this.logger.info(`IR Blockers: ${summary.irBlockers}`);
    this.logger.info(`BR Blockers: ${summary.brBlockers}`);
    this.logger.info(`IR Warnings: ${summary.irWarnings}`);
    this.logger.info(`BR Warnings: ${summary.brWarnings}`);
    this.logger.info(`Migration Warnings: ${summary.migrationWarnings}`);
    this.logger.info(`No Direct Impact: ${summary.noDirectImpact}`);

    return { issues, summary };
  }

  /**
   * Refine impact classification based on context
   */
  _refineImpact(issue, inventory) {
    // Rule 1: Missing assemblies are always IR blockers
    if (issue.category === 'MISSING_DEPENDENCY') {
      issue.impactType = 'IR_BLOCKER';
      issue.confidence = Math.max(issue.confidence, 0.95);
      return;
    }

    // Rule 2: WinForms in source files is MIGRATION_WARNING, not IR_BLOCKER
    // (You can still extract business logic from WinForms code)
    if (issue.ruleId && issue.ruleId.includes('PLATFORM-WIN-002') && issue.file && issue.file.endsWith('.vb')) {
      issue.impactType = 'MIGRATION_WARNING';
      return;
    }

    // Rule 3: Security issues in config don't block IR
    if (issue.category === 'SECURITY' && issue.impactType === 'IR_BLOCKER') {
      issue.impactType = 'IR_WARNING';
      return;
    }

    // Rule 4: Event handlers containing business logic → BR_WARNING
    if (['VBNET-EVT-001', 'VBNET-EVT-002', 'VBNET-EVT-003'].includes(issue.ruleId)) {
      // Check if the file is a Designer file (no business logic)
      if (issue.file && issue.file.includes('.Designer.')) {
        issue.impactType = 'NO_DIRECT_IMPACT';
        issue.severity = 'LOW';
        return;
      }
      // Check if it's a form file — event handlers may contain business logic
      if (issue.file && (issue.file.includes('Form') || issue.file.includes('form'))) {
        issue.impactType = 'BR_WARNING';
        return;
      }
    }

    // Rule 5: Database dependencies that are SUPPORTED don't affect IR/BR
    if (issue.category === 'DATABASE_DEPENDENCY' && issue.compatibility === 'SUPPORTED') {
      issue.impactType = 'NO_DIRECT_IMPACT';
      return;
    }

    // Rule 6: ComVisible in AssemblyInfo has no impact (boilerplate attribute)
    if (issue.file && issue.file.includes('AssemblyInfo')) {
      // ComVisible(False) is a standard .NET attribute — NOT actual COM interop usage
      if (issue.ruleId === 'PLATFORM-WIN-004' || issue.ruleId === 'PLATFORM-WIN-015' ||
          (issue.symbol && issue.symbol.includes('ComVisible'))) {
        issue.impactType = 'NO_DIRECT_IMPACT';
        issue.severity = 'LOW';
        issue.ruleDescription = (issue.ruleDescription || '') + ' [Note: This is a standard .NET assembly attribute, not actual COM interop usage.]';
        return;
      }
    }

    // Rule 6b: Designer/generated files rarely contain business logic
    if (issue.file && (issue.file.includes('.Designer.') || issue.file.includes('.designer.'))) {
      if (issue.impactType === 'IR_BLOCKER' && issue.category !== 'MISSING_DEPENDENCY') {
        issue.impactType = 'MIGRATION_WARNING';
      }
      if (issue.impactType === 'BR_WARNING' || issue.impactType === 'BR_BLOCKER') {
        issue.impactType = 'NO_DIRECT_IMPACT';
      }
      return;
    }

    // Rule 7: Shared keyword is trivially mappable (static)
    if (issue.ruleId === 'VBNET-SHARED-001') {
      issue.impactType = 'NO_DIRECT_IMPACT';
      return;
    }

    // Rule 8: Structure keyword maps to Java record/class
    if (issue.ruleId === 'VBNET-STRUCT-001') {
      issue.impactType = 'NO_DIRECT_IMPACT';
      return;
    }
  }

  /**
   * Calculate issue summary statistics
   */
  _calculateSummary(issues) {
    const summary = {
      totalIssues: issues.length,
      critical: 0,
      high: 0,
      medium: 0,
      low: 0,
      irBlockers: 0,
      brBlockers: 0,
      irWarnings: 0,
      brWarnings: 0,
      migrationWarnings: 0,
      noDirectImpact: 0,
      byCategory: {},
      byFile: {}
    };

    for (const issue of issues) {
      // Severity counts
      switch (issue.severity) {
        case 'CRITICAL': summary.critical++; break;
        case 'HIGH': summary.high++; break;
        case 'MEDIUM': summary.medium++; break;
        case 'LOW': summary.low++; break;
      }

      // Impact counts
      switch (issue.impactType) {
        case 'IR_BLOCKER': summary.irBlockers++; break;
        case 'BR_BLOCKER': summary.brBlockers++; break;
        case 'IR_WARNING': summary.irWarnings++; break;
        case 'BR_WARNING': summary.brWarnings++; break;
        case 'MIGRATION_WARNING': summary.migrationWarnings++; break;
        case 'NO_DIRECT_IMPACT': summary.noDirectImpact++; break;
      }

      // Category counts
      summary.byCategory[issue.category] = (summary.byCategory[issue.category] || 0) + 1;

      // File counts
      if (issue.file) {
        summary.byFile[issue.file] = (summary.byFile[issue.file] || 0) + 1;
      }
    }

    return summary;
  }
}

module.exports = ImpactClassifier;
