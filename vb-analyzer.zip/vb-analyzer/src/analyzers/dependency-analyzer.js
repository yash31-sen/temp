const path = require('path');

/**
 * Phase 4: Dependency Analyzer
 * 
 * Analyzes project dependencies including NuGet packages, DLL references,
 * external executables, and database dependencies.
 */
class DependencyAnalyzer {
  constructor(logger) {
    this.logger = logger;
  }

  /**
   * Analyze all dependencies in the project
   * @param {Object} inventory - Project inventory from ProjectScanner
   * @returns {Object[]} Array of dependency-related issues
   */
  analyze(inventory) {
    this.logger.section('Phase 4: Dependency Analysis');
    const issues = [];

    // 1. Check for missing local assemblies
    for (const asm of (inventory.missingAssemblies || [])) {
      issues.push({
        ruleId: 'DEP-MISSING-ASM',
        category: 'MISSING_DEPENDENCY',
        severity: 'CRITICAL',
        impactType: 'IR_BLOCKER',
        file: inventory.projectFiles[0] || 'unknown',
        line: null,
        symbol: asm.name,
        evidence: `Missing DLL: ${asm.hintPath} (resolved to ${asm.resolvedPath})`,
        confidence: 0.99,
        source: ['DEPENDENCY_ANALYZER'],
        ruleName: 'Missing Assembly Reference',
        ruleDescription: `Referenced assembly ${asm.name} not found at ${asm.hintPath}. Build will fail.`,
        migrationDifficulty: 'HIGH'
      });
    }

    // 2. Classify external assemblies
    for (const asm of (inventory.externalAssemblies || [])) {
      if (!asm.exists) continue; // Already handled as missing

      const classification = this._classifyAssembly(asm.name);
      if (classification.report) {
        issues.push({
          ruleId: `DEP-EXT-${asm.name.replace(/\./g, '-')}`,
          category: 'EXTERNAL_DEPENDENCY',
          severity: classification.severity,
          impactType: classification.impact,
          file: asm.hintPath || 'unknown',
          line: null,
          symbol: asm.name,
          evidence: `External assembly: ${asm.name} (${(asm.fileSize / 1024).toFixed(0)} KB)`,
          confidence: classification.confidence,
          source: ['DEPENDENCY_ANALYZER'],
          ruleName: `External Assembly: ${asm.name}`,
          ruleDescription: classification.description,
          migrationDifficulty: classification.difficulty
        });
      }
    }

    // 3. Analyze database dependencies
    for (const dbRef of (inventory.databaseReferences || [])) {
      const dbClassification = this._classifyDatabase(dbRef);
      issues.push({
        ruleId: `DEP-DB-${dbRef.dbType}`,
        category: 'DATABASE_DEPENDENCY',
        severity: dbClassification.severity,
        impactType: dbClassification.impact,
        file: path.relative(inventory.projectRoot, dbRef.source) || 'App.config',
        line: null,
        symbol: dbRef.providerName || dbRef.dbType,
        evidence: `Connection: ${dbRef.name} → ${dbRef.dbType} (${this._maskConnectionString(dbRef.connectionString)})`,
        confidence: dbClassification.confidence,
        source: ['DEPENDENCY_ANALYZER'],
        ruleName: `Database Dependency: ${dbRef.dbType}`,
        ruleDescription: dbClassification.description,
        migrationDifficulty: dbClassification.difficulty,
        dbType: dbRef.dbType,
        compatibility: dbClassification.compatibility
      });
    }

    // 4. Check for .NET framework-specific dependencies
    const frameworkDeps = (inventory.dependencies || []).filter(d =>
      d.type === 'assembly' && !d.isLocal
    );

    for (const dep of frameworkDeps) {
      const classification = this._classifyFrameworkAssembly(dep.name);
      if (classification.report) {
        issues.push({
          ruleId: `DEP-FW-${dep.name.replace(/\./g, '-')}`,
          category: 'FRAMEWORK_DEPENDENCY',
          severity: classification.severity,
          impactType: classification.impact,
          file: inventory.projectFiles[0] || 'unknown',
          line: null,
          symbol: dep.name,
          evidence: `Framework assembly: ${dep.name}`,
          confidence: classification.confidence,
          source: ['DEPENDENCY_ANALYZER'],
          ruleName: `Framework Dependency: ${dep.name}`,
          ruleDescription: classification.description,
          migrationDifficulty: classification.difficulty
        });
      }
    }

    this.logger.success(`Dependency analysis found ${issues.length} dependency issues`);
    return issues;
  }

  /**
   * Classify a third-party assembly
   */
  _classifyAssembly(name) {
    const lowerName = name.toLowerCase();

    // Known cross-platform compatible
    if (lowerName.includes('mysql.data')) {
      return {
        report: true,
        severity: 'LOW',
        impact: 'NO_DIRECT_IMPACT',
        confidence: 0.95,
        difficulty: 'LOW',
        description: 'MySQL connector. Java equivalent: mysql-connector-java / Spring Data JPA.',
        compatibility: 'SUPPORTED'
      };
    }
    if (lowerName.includes('google.protobuf')) {
      return {
        report: true,
        severity: 'LOW',
        impact: 'NO_DIRECT_IMPACT',
        confidence: 0.95,
        difficulty: 'LOW',
        description: 'Google Protocol Buffers. Direct Java equivalent available (protobuf-java).',
        compatibility: 'SUPPORTED'
      };
    }
    if (lowerName.includes('bouncycastle')) {
      return {
        report: true,
        severity: 'LOW',
        impact: 'NO_DIRECT_IMPACT',
        confidence: 0.95,
        difficulty: 'LOW',
        description: 'BouncyCastle cryptography library. Direct Java equivalent available (org.bouncycastle).',
        compatibility: 'SUPPORTED'
      };
    }
    if (lowerName.includes('system.buffers') || lowerName.includes('system.memory') ||
        lowerName.includes('system.threading') || lowerName.includes('system.runtime') ||
        lowerName.includes('system.io.pipelines')) {
      return {
        report: false, // Low-level .NET plumbing, not directly relevant
        severity: 'LOW',
        impact: 'NO_DIRECT_IMPACT',
        confidence: 0.90,
        difficulty: 'LOW',
        description: '.NET standard library polyfill. Will be replaced by Java standard library equivalents.',
        compatibility: 'SUPPORTED'
      };
    }
    if (lowerName.includes('k4os.compression') || lowerName.includes('k4os.hash')) {
      return {
        report: true,
        severity: 'LOW',
        impact: 'NO_DIRECT_IMPACT',
        confidence: 0.90,
        difficulty: 'LOW',
        description: 'Compression/hashing library. Java equivalents available (lz4-java, etc.).',
        compatibility: 'SUPPORTED'
      };
    }

    // Unknown — report with lower confidence
    return {
      report: true,
      severity: 'MEDIUM',
      impact: 'MIGRATION_WARNING',
      confidence: 0.70,
      difficulty: 'UNKNOWN',
      description: `External assembly ${name} — Java equivalent needs investigation.`,
      compatibility: 'UNKNOWN'
    };
  }

  /**
   * Classify a framework assembly
   */
  _classifyFrameworkAssembly(name) {
    const mapping = {
      'System': { report: false },
      'System.Core': { report: false },
      'System.Data': {
        report: true,
        severity: 'LOW',
        impact: 'MIGRATION_WARNING',
        confidence: 0.90,
        difficulty: 'MEDIUM',
        description: 'ADO.NET data access. Map to Spring Data JPA / JDBC in Java.'
      },
      'System.Xml': { report: false },
      'System.Xml.Linq': { report: false },
      'System.Configuration': {
        report: true,
        severity: 'LOW',
        impact: 'MIGRATION_WARNING',
        confidence: 0.92,
        difficulty: 'LOW',
        description: 'System.Configuration for appSettings/connectionStrings. Map to Spring Boot application.properties.'
      },
      'System.Deployment': {
        report: true,
        severity: 'MEDIUM',
        impact: 'MIGRATION_WARNING',
        confidence: 0.90,
        difficulty: 'MEDIUM',
        description: 'ClickOnce deployment — Windows-specific. Not needed in Java/Spring Boot.'
      },
      'System.Drawing': {
        report: false // Already caught by PlatformAnalyzer
      },
      'System.Windows.Forms': {
        report: false // Already caught by PlatformAnalyzer
      }
    };

    return mapping[name] || { report: false };
  }

  /**
   * Classify a database dependency
   */
  _classifyDatabase(dbRef) {
    const type = dbRef.dbType;

    const classifications = {
      'MYSQL': {
        severity: 'LOW',
        impact: 'NO_DIRECT_IMPACT',
        confidence: 0.96,
        difficulty: 'LOW',
        description: 'MySQL database. Fully supported in Java/Spring Boot via mysql-connector-java.',
        compatibility: 'SUPPORTED'
      },
      'SQL_SERVER': {
        severity: 'MEDIUM',
        impact: 'MIGRATION_WARNING',
        confidence: 0.93,
        difficulty: 'MEDIUM',
        description: 'SQL Server. Java JDBC driver available (mssql-jdbc). Check for T-SQL specific syntax.',
        compatibility: 'SUPPORTED'
      },
      'ORACLE': {
        severity: 'MEDIUM',
        impact: 'MIGRATION_WARNING',
        confidence: 0.90,
        difficulty: 'MEDIUM',
        description: 'Oracle Database. Java JDBC driver available (ojdbc). Check for PL/SQL specifics.',
        compatibility: 'SUPPORTED'
      },
      'POSTGRESQL': {
        severity: 'LOW',
        impact: 'NO_DIRECT_IMPACT',
        confidence: 0.96,
        difficulty: 'LOW',
        description: 'PostgreSQL. Excellent Java/Spring Boot support.',
        compatibility: 'SUPPORTED'
      },
      'OLEDB': {
        severity: 'HIGH',
        impact: 'MIGRATION_WARNING',
        confidence: 0.92,
        difficulty: 'HIGH',
        description: 'OLE DB is Windows-specific. Must identify underlying DB and use appropriate JDBC driver.',
        compatibility: 'WINDOWS_SPECIFIC'
      },
      'ODBC': {
        severity: 'MEDIUM',
        impact: 'MIGRATION_WARNING',
        confidence: 0.85,
        difficulty: 'MEDIUM',
        description: 'ODBC — cross-platform in theory but DSN configs may be Windows-specific.',
        compatibility: 'POTENTIALLY_INCOMPATIBLE'
      }
    };

    return classifications[type] || {
      severity: 'MEDIUM',
      impact: 'MIGRATION_WARNING',
      confidence: 0.70,
      difficulty: 'UNKNOWN',
      description: `Unknown database type: ${type}. Requires investigation.`,
      compatibility: 'UNKNOWN'
    };
  }

  /**
   * Mask sensitive parts of a connection string
   */
  _maskConnectionString(connStr) {
    if (!connStr) return '';
    return connStr
      .replace(/Pwd=[^;]+/gi, 'Pwd=***')
      .replace(/Password=[^;]+/gi, 'Password=***')
      .replace(/Uid=[^;]+/gi, 'Uid=***')
      .replace(/User\s*ID=[^;]+/gi, 'User ID=***');
  }
}

module.exports = DependencyAnalyzer;
