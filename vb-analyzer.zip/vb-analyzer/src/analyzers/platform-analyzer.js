const path = require('path');
const { readFileSafe } = require('../utils/file-utils');

/**
 * Phase 3: Platform Dependency Analyzer
 * 
 * Detects Windows-specific and platform-dependent code patterns
 * that will cause issues when migrating to Linux/Java.
 */
class PlatformAnalyzer {
  constructor(logger) {
    this.logger = logger;
  }

  /**
   * Analyze project inventory for platform dependencies
   * @param {Object} inventory - Project inventory from ProjectScanner
   * @returns {Object[]} Array of platform-specific issues
   */
  analyze(inventory) {
    this.logger.section('Phase 3: Platform Dependency Analysis');
    const issues = [];

    // 1. Check output type
    if (inventory.outputType && inventory.outputType.toLowerCase() === 'winexe') {
      issues.push({
        ruleId: 'PLATFORM-WIN-014',
        category: 'PLATFORM_DEPENDENCY',
        severity: 'HIGH',
        impactType: 'MIGRATION_WARNING',
        file: inventory.projectFiles[0] || 'unknown',
        line: null,
        symbol: 'WinExe',
        evidence: `OutputType: ${inventory.outputType}`,
        confidence: 0.98,
        source: ['PLATFORM_ANALYZER'],
        ruleName: 'WinExe Output Type',
        ruleDescription: 'Project targets WinExe output type. Must be converted to a web application or service.',
        migrationDifficulty: 'HIGH'
      });
    }

    // 2. Check assembly references for platform-specific ones
    const winOnlyAssemblies = {
      'System.Windows.Forms': { severity: 'HIGH', impact: 'MIGRATION_WARNING', difficulty: 'HIGH' },
      'System.Drawing': { severity: 'HIGH', impact: 'MIGRATION_WARNING', difficulty: 'MEDIUM' },
      'System.Deployment': { severity: 'MEDIUM', impact: 'MIGRATION_WARNING', difficulty: 'MEDIUM' },
      'System.ServiceProcess': { severity: 'HIGH', impact: 'MIGRATION_WARNING', difficulty: 'HIGH' },
      'Microsoft.Win32': { severity: 'HIGH', impact: 'MIGRATION_WARNING', difficulty: 'HIGH' },
    };

    for (const dep of inventory.dependencies) {
      const config = winOnlyAssemblies[dep.name];
      if (config) {
        issues.push({
          ruleId: `PLATFORM-DEP-${dep.name.replace(/\./g, '-')}`,
          category: 'PLATFORM_DEPENDENCY',
          severity: config.severity,
          impactType: config.impact,
          file: inventory.projectFiles[0] || 'unknown',
          line: null,
          symbol: dep.name,
          evidence: `Assembly Reference: ${dep.name}`,
          confidence: 0.97,
          source: ['PLATFORM_ANALYZER'],
          ruleName: `${dep.name} Assembly Reference`,
          ruleDescription: `${dep.name} is a Windows-specific assembly that requires replacement for Linux/Java migration.`,
          migrationDifficulty: config.difficulty
        });
      }
    }

    // 3. Check VB.NET project-level imports for platform-specific namespaces
    const winOnlyImports = [
      'System.Windows.Forms',
      'System.Drawing',
      'Microsoft.Win32'
    ];

    for (const imp of (inventory.imports || [])) {
      if (winOnlyImports.includes(imp)) {
        issues.push({
          ruleId: `PLATFORM-IMP-${imp.replace(/\./g, '-')}`,
          category: 'PLATFORM_DEPENDENCY',
          severity: 'HIGH',
          impactType: 'MIGRATION_WARNING',
          file: inventory.projectFiles[0] || 'unknown',
          line: null,
          symbol: imp,
          evidence: `Project-level Import: ${imp}`,
          confidence: 0.96,
          source: ['PLATFORM_ANALYZER'],
          ruleName: `Project Import: ${imp}`,
          ruleDescription: `Project-level import of ${imp} indicates Windows dependency throughout the project.`,
          migrationDifficulty: 'HIGH'
        });
      }
    }

    // 4. Check target framework compatibility
    const framework = inventory.targetFramework || '';
    if (framework.startsWith('v') && !framework.includes('netcoreapp') && !framework.includes('net5') && !framework.includes('net6') && !framework.includes('net7') && !framework.includes('net8')) {
      issues.push({
        ruleId: 'PLATFORM-FW-001',
        category: 'FRAMEWORK_DEPENDENCY',
        severity: 'MEDIUM',
        impactType: 'IR_WARNING',
        file: inventory.projectFiles[0] || 'unknown',
        line: null,
        symbol: framework,
        evidence: `Target Framework: ${framework}`,
        confidence: 0.95,
        source: ['PLATFORM_ANALYZER'],
        ruleName: '.NET Framework (non-.NET Core/5+)',
        ruleDescription: `Project targets ${framework} which is Windows-only. .NET Core/.NET 5+ or Java/Spring Boot required for Linux.`,
        migrationDifficulty: 'HIGH'
      });
    }

    this.logger.success(`Platform analysis found ${issues.length} platform-specific issues`);
    return issues;
  }
}

module.exports = PlatformAnalyzer;
