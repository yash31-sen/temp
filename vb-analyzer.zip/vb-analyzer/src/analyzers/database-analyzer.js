const path = require('path');
const { readFileSafe } = require('../utils/file-utils');

/**
 * Phase 4 (supplement): Database Analyzer
 * 
 * Deep analysis of database usage patterns in VB.NET source code.
 * Detects connection patterns, query construction, stored procedure calls, etc.
 */
class DatabaseAnalyzer {
  constructor(logger) {
    this.logger = logger;
  }

  /**
   * Analyze source files for database usage patterns
   * @param {Object} inventory - Project inventory
   * @returns {Object[]} Array of database-related issues
   */
  analyze(inventory) {
    this.logger.subsection('Database Pattern Analysis');
    const issues = [];

    for (const relPath of inventory.sourceFiles) {
      const absPath = path.resolve(inventory.projectRoot, relPath);
      const content = readFileSafe(absPath);
      if (!content) continue;

      const lines = content.split(/\r?\n/);

      // Detect inline SQL construction (potential SQL injection)
      this._detectInlineSql(lines, relPath, issues);

      // Detect stored procedure calls
      this._detectStoredProcCalls(lines, relPath, issues);

      // Detect connection string in source (not config)
      this._detectHardcodedConnStrings(lines, relPath, issues);
    }

    // Also analyze config files for credential exposure
    for (const cfg of (inventory.configurationFiles || [])) {
      for (const cs of (cfg.connectionStrings || [])) {
        if (this._hasCredentials(cs.connectionString)) {
          issues.push({
            ruleId: 'DB-SEC-001',
            category: 'SECURITY',
            severity: 'HIGH',
            impactType: 'IR_WARNING',
            file: path.relative(inventory.projectRoot, cfg.filePath),
            line: null,
            symbol: cs.name,
            evidence: `Connection string "${cs.name}" contains plaintext credentials`,
            confidence: 0.92,
            source: ['DATABASE_ANALYZER'],
            ruleName: 'Plaintext Database Credentials in Config',
            ruleDescription: 'Database credentials stored in plaintext in config file. Should be encrypted or externalized (Spring Boot Vault, environment variables).',
            migrationDifficulty: 'LOW'
          });
        }
      }
    }

    this.logger.success(`Database analysis found ${issues.length} database-related issues`);
    return issues;
  }

  _detectInlineSql(lines, relPath, issues) {
    const sqlKeywords = /\b(SELECT|INSERT|UPDATE|DELETE|CREATE|ALTER|DROP|TRUNCATE)\s+/i;
    const stringConcat = /&\s*\w+|"\s*&/;

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      if (line.startsWith("'")) continue;

      if (sqlKeywords.test(line) && stringConcat.test(line)) {
        // Check if parameterized (has @param pattern)
        const hasParams = /@\w+/.test(line);
        if (!hasParams) {
          issues.push({
            ruleId: 'DB-SQLI-001',
            category: 'SECURITY',
            severity: 'HIGH',
            impactType: 'BR_WARNING',
            file: relPath,
            line: i + 1,
            symbol: 'SQL Concatenation',
            evidence: line.substring(0, 200),
            confidence: 0.72,
            source: ['DATABASE_ANALYZER'],
            ruleName: 'Potential SQL Injection via String Concatenation',
            ruleDescription: 'SQL query appears to be built via string concatenation without parameterization. May be vulnerable to SQL injection. Verify and use parameterized queries.',
            migrationDifficulty: 'MEDIUM'
          });
        }
      }
    }
  }

  _detectStoredProcCalls(lines, relPath, issues) {
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      if (line.startsWith("'")) continue;

      if (/CommandType\s*=?\s*\.?StoredProcedure/i.test(line) ||
          /CommandType\s*=\s*4/i.test(line)) {
        issues.push({
          ruleId: 'DB-SPROC-002',
          category: 'DATABASE_DEPENDENCY',
          severity: 'MEDIUM',
          impactType: 'BR_WARNING',
          file: relPath,
          line: i + 1,
          symbol: 'StoredProcedure',
          evidence: line.substring(0, 200),
          confidence: 0.90,
          source: ['DATABASE_ANALYZER'],
          ruleName: 'Stored Procedure Usage',
          ruleDescription: 'Stored procedure calls may contain business logic that needs to be extracted and mapped during migration.',
          migrationDifficulty: 'MEDIUM'
        });
      }
    }
  }

  _detectHardcodedConnStrings(lines, relPath, issues) {
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      if (line.startsWith("'")) continue;

      // Detect hardcoded connection parameters in source code
      if (/Password\s*=\s*"[^"]+"/i.test(line) ||
          /\.Password\s*=\s*"[^"]+"/i.test(line)) {
        issues.push({
          ruleId: 'DB-SEC-002',
          category: 'SECURITY',
          severity: 'HIGH',
          impactType: 'IR_WARNING',
          file: relPath,
          line: i + 1,
          symbol: 'Hardcoded Password',
          evidence: line.replace(/"[^"]+"/g, '"***"').substring(0, 200),
          confidence: 0.88,
          source: ['DATABASE_ANALYZER'],
          ruleName: 'Hardcoded Database Password in Source',
          ruleDescription: 'Database password hardcoded in source code. Must be externalized to secure configuration.',
          migrationDifficulty: 'LOW'
        });
      }
    }
  }

  _hasCredentials(connStr) {
    if (!connStr) return false;
    return /Pwd=\w+/i.test(connStr) || /Password=\w+/i.test(connStr);
  }
}

module.exports = DatabaseAnalyzer;
