const fs = require('fs');
const path = require('path');
const { readFileSafe } = require('../utils/file-utils');

/**
 * Phase 2: VB.NET Static Analyzer
 * 
 * Scans every .vb source file for VB.NET-specific constructs, patterns,
 * and potential migration issues using regex-based pattern matching.
 */
class StaticAnalyzer {
  constructor(logger) {
    this.logger = logger;
  }

  /**
   * Analyze all source files in the project
   * @param {Object} inventory - Project inventory from ProjectScanner
   * @param {Object[]} rules - Combined rules from all rule files
   * @returns {Object[]} Array of detected issues
   */
  analyze(inventory, rules) {
    this.logger.section('Phase 2: Static Analysis');
    const issues = [];

    // Scan all VB source files
    for (const relPath of inventory.sourceFiles) {
      // Skip .sln files — not actual source code
      if (relPath.endsWith('.sln')) continue;

      const absPath = path.resolve(inventory.projectRoot, relPath);
      const content = readFileSafe(absPath);
      if (!content) {
        this.logger.warn(`Could not read: ${relPath}`);
        continue;
      }

      this.logger.debug(`Analyzing: ${relPath}`);
      const lines = content.split(/\r?\n/);

      // Apply each rule against each line
      for (const rule of rules) {
        const regex = new RegExp(rule.detectionPattern, 'gi');

        for (let lineIdx = 0; lineIdx < lines.length; lineIdx++) {
          const line = lines[lineIdx];
          const trimmed = line.trim();

          // Skip comment-only lines
          if (trimmed.startsWith("'") || trimmed.startsWith("REM ")) continue;

          let match;
          regex.lastIndex = 0;
          while ((match = regex.exec(line)) !== null) {
            issues.push({
              ruleId: rule.ruleId,
              category: rule.category,
              severity: rule.severity || 'MEDIUM',
              impactType: rule.defaultImpact || 'MIGRATION_WARNING',
              file: relPath,
              line: lineIdx + 1,
              column: match.index + 1,
              symbol: match[0],
              evidence: trimmed.substring(0, 200),
              confidence: rule.confidence || 0.80,
              source: ['STATIC_ANALYZER'],
              ruleName: rule.name,
              ruleDescription: rule.description,
              migrationDifficulty: rule.migrationDifficulty || 'UNKNOWN'
            });

            // For non-global single-match patterns, break after first match per line
            if (!regex.global) break;
          }
        }
      }
    }

    // Also analyze .vbproj content itself for platform patterns
    for (const relPath of inventory.projectFiles) {
      if (!relPath.endsWith('.vbproj')) continue;
      const absPath = path.resolve(inventory.projectRoot, relPath);
      const content = readFileSafe(absPath);
      if (!content) continue;

      this.logger.debug(`Analyzing project file: ${relPath}`);
      const lines = content.split(/\r?\n/);

      for (const rule of rules) {
        // Only apply certain rules to project files
        if (rule.ruleId !== 'PLATFORM-WIN-014') continue;

        const regex = new RegExp(rule.detectionPattern, 'gi');
        for (let lineIdx = 0; lineIdx < lines.length; lineIdx++) {
          let match;
          regex.lastIndex = 0;
          while ((match = regex.exec(lines[lineIdx])) !== null) {
            issues.push({
              ruleId: rule.ruleId,
              category: rule.category,
              severity: rule.severity,
              impactType: rule.defaultImpact,
              file: relPath,
              line: lineIdx + 1,
              column: match.index + 1,
              symbol: match[0],
              evidence: lines[lineIdx].trim().substring(0, 200),
              confidence: rule.confidence,
              source: ['STATIC_ANALYZER'],
              ruleName: rule.name,
              ruleDescription: rule.description,
              migrationDifficulty: rule.migrationDifficulty
            });
          }
        }
      }
    }

    // Deduplicate issues by ruleId + file + line
    const dedupKey = (issue) => `${issue.ruleId}|${issue.file}|${issue.line}`;
    const seen = new Set();
    let dedupedIssues = [];
    for (const issue of issues) {
      const key = dedupKey(issue);
      if (!seen.has(key)) {
        seen.add(key);
        dedupedIssues.push(issue);
      }
    }

    // Consolidate Designer/generated file noise:
    // When the same rule fires many times in a .Designer.vb file,
    // collapse into a single issue with an occurrence count.
    dedupedIssues = this._consolidateDesignerIssues(dedupedIssues);

    this.logger.success(`Static analysis found ${dedupedIssues.length} issues across ${inventory.sourceFiles.length} source files`);
    return dedupedIssues;
  }

  /**
   * Consolidate repeated rule matches in Designer/generated files.
   * Instead of 200+ individual WinForms matches in MainForm.Designer.vb,
   * produce a single issue with occurrence count.
   */
  _consolidateDesignerIssues(issues) {
    const designerFiles = new Set();
    const normalIssues = [];
    const designerIssueMap = new Map(); // key: ruleId|file → { issue, count, lines[] }

    for (const issue of issues) {
      const isDesigner = issue.file && (
        issue.file.includes('.Designer.') ||
        issue.file.includes('.designer.')
      );

      if (isDesigner) {
        designerFiles.add(issue.file);
        const key = `${issue.ruleId}|${issue.file}`;
        if (designerIssueMap.has(key)) {
          const entry = designerIssueMap.get(key);
          entry.count++;
          if (issue.line) entry.lines.push(issue.line);
        } else {
          designerIssueMap.set(key, {
            issue: { ...issue },
            count: 1,
            lines: issue.line ? [issue.line] : []
          });
        }
      } else {
        normalIssues.push(issue);
      }
    }

    // Convert consolidated designer issues
    for (const [, entry] of designerIssueMap) {
      const consolidated = entry.issue;
      consolidated.line = entry.lines.length > 0 ? entry.lines[0] : null;
      consolidated.evidence = `[${entry.count} occurrences in generated/designer file] ${consolidated.evidence}`;
      consolidated.confidence = Math.max(0.60, consolidated.confidence - 0.10); // lower confidence for designer files
      consolidated.occurrenceCount = entry.count;
      // Designer files rarely contain business logic
      if (consolidated.impactType === 'BR_WARNING') {
        consolidated.impactType = 'NO_DIRECT_IMPACT';
      }
      normalIssues.push(consolidated);
    }

    return normalIssues;
  }
}

module.exports = StaticAnalyzer;
