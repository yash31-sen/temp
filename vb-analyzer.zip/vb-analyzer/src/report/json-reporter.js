const fs = require('fs');
const path = require('path');

/**
 * JSON Report Generator
 * 
 * Produces the final machine-readable JSON report containing:
 * - Project metadata
 * - Analysis summary
 * - IR/BR readiness assessment
 * - All detected issues with classification
 */
class JsonReporter {
  constructor(logger) {
    this.logger = logger;
  }

  /**
   * Generate the final JSON report
   * @param {Object} inventory - Project inventory from scanner
   * @param {Object} classificationResult - { issues, summary } from classifier
   * @param {Object} options - Report options (target, etc.)
   * @returns {Object} The complete report object
   */
  generate(inventory, classificationResult, options = {}) {
    this.logger.section('Report Generation');

    const { issues, summary } = classificationResult;

    const report = {
      project: inventory.project,
      analysisTimestamp: new Date().toISOString(),
      analyzerVersion: '1.0.0-mvp1',
      
      projectInfo: {
        projectRoot: inventory.projectRoot,
        targetFramework: inventory.targetFramework,
        outputType: inventory.outputType,
        rootNamespace: inventory.rootNamespace,
        assemblyName: inventory.assemblyName,
        sourceFileCount: inventory.summary.sourceFileCount,
        dependencyCount: inventory.dependencies.length,
        externalAssemblyCount: inventory.externalAssemblies.length,
        missingAssemblyCount: inventory.missingAssemblies.length
      },

      targetMigration: {
        sourceLanguage: 'VB.NET',
        targetLanguage: options.target || 'java-spring-angular',
        targetPlatform: options.targetPlatform || 'linux',
        targetStack: {
          backend: 'Java 17+ / Spring Boot',
          frontend: 'Angular',
          database: 'Preserve existing (JDBC)',
          os: 'Linux'
        }
      },

      analysisStatus: 'COMPLETED',
      
      summary: {
        totalIssues: summary.totalIssues,
        critical: summary.critical,
        high: summary.high,
        medium: summary.medium,
        low: summary.low,
        irBlockers: summary.irBlockers,
        brBlockers: summary.brBlockers,
        irWarnings: summary.irWarnings,
        brWarnings: summary.brWarnings,
        migrationWarnings: summary.migrationWarnings,
        noDirectImpact: summary.noDirectImpact,
        byCategory: summary.byCategory,
        byFile: summary.byFile
      },

      irGenerationReady: summary.irBlockers === 0,
      brGenerationReady: summary.brBlockers === 0,

      readinessAssessment: this._generateReadinessAssessment(summary, inventory),

      dependencies: {
        frameworkAssemblies: inventory.dependencies.filter(d => d.type === 'assembly' && !d.isLocal).map(d => d.name),
        externalAssemblies: inventory.externalAssemblies.map(a => ({
          name: a.name,
          exists: a.exists,
          sizeBytesKB: Math.round(a.fileSize / 1024)
        })),
        missingAssemblies: inventory.missingAssemblies.map(a => ({
          name: a.name,
          expectedPath: a.hintPath
        })),
        databaseReferences: inventory.databaseReferences.map(db => ({
          name: db.name,
          dbType: db.dbType,
          providerName: db.providerName
        }))
      },

      issues: issues.map(issue => ({
        id: issue.id,
        ruleId: issue.ruleId,
        category: issue.category,
        severity: issue.severity,
        impactType: issue.impactType,
        file: issue.file,
        line: issue.line,
        column: issue.column || null,
        symbol: issue.symbol,
        evidence: issue.evidence,
        confidence: parseFloat(issue.confidence.toFixed(2)),
        source: issue.source,
        ruleName: issue.ruleName,
        ruleDescription: issue.ruleDescription,
        migrationDifficulty: issue.migrationDifficulty,
        reason: issue.reason || issue.ruleDescription || `Detected ${issue.symbol || issue.ruleName} construct which requires migration attention.`,
        impact: issue.impact || this._inferIssueImpact(issue),
        suggestedResolution: issue.suggestedResolution || this._generateSuggestedResolution(issue, options.target || 'java-spring-angular'),
        migrationStrategy: issue.migrationStrategy || this._generateMigrationStrategy(issue, options.target || 'java-spring-angular'),
        irGenerationImpact: issue.impactType === 'IR_BLOCKER' ? 'CRITICAL: Blocks IR generation until resolved' : (issue.impactType === 'IR_WARNING' ? 'WARNING: May degrade IR completeness' : 'NONE'),
        brGenerationImpact: issue.impactType === 'BR_BLOCKER' ? 'CRITICAL: Blocks Business Rule extraction' : (issue.impactType === 'BR_WARNING' ? 'WARNING: Requires manual verification of extracted Business Rules' : 'NONE'),
        additionalChecks: issue.additionalChecks || []
      }))
    };

    return report;
  }

  /**
   * Write report to a JSON file
   * @param {Object} report - The report object
   * @param {string} outputPath - Absolute path for the output file
   */
  writeToFile(report, outputPath) {
    const dir = path.dirname(outputPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    fs.writeFileSync(outputPath, JSON.stringify(report, null, 2), 'utf-8');
    this.logger.success(`JSON report written to: ${outputPath}`);
  }

  /**
   * Generate a readiness assessment
   */
  _generateReadinessAssessment(summary, inventory) {
    const assessment = {
      irReady: summary.irBlockers === 0,
      brReady: summary.brBlockers === 0,
      overallReadiness: 'UNKNOWN',
      blockers: [],
      warnings: [],
      recommendations: []
    };

    // Determine overall readiness
    if (summary.irBlockers > 0) {
      assessment.overallReadiness = 'BLOCKED';
      assessment.blockers.push(`${summary.irBlockers} IR blocker(s) must be resolved before IR generation can proceed.`);
    } else if (summary.critical > 0 || summary.high > 3) {
      assessment.overallReadiness = 'AT_RISK';
      assessment.warnings.push('Multiple high-severity issues detected. IR generation may succeed but results require careful review.');
    } else if (summary.high > 0 || summary.medium > 5) {
      assessment.overallReadiness = 'CONDITIONAL';
      assessment.warnings.push('Some issues detected that may affect IR/BR quality. Review recommended before proceeding.');
    } else {
      assessment.overallReadiness = 'READY';
    }

    // Generate recommendations
    if (inventory.outputType === 'WinExe') {
      assessment.recommendations.push('Separate UI layer (WinForms) from business logic before migration. Business logic should be extracted into service classes.');
    }

    if (summary.byCategory['SECURITY'] > 0) {
      assessment.recommendations.push('Externalize all hardcoded credentials to environment variables or a secrets manager before migration.');
    }

    if (summary.byCategory['PLATFORM_DEPENDENCY'] > 0) {
      assessment.recommendations.push('Identify which platform-specific code contains business logic vs. infrastructure. Only business logic needs to be migrated; infrastructure will be replaced by Spring Boot equivalents.');
    }

    if (summary.byCategory['VBNET_CONSTRUCT'] > 0) {
      assessment.recommendations.push('VB.NET-specific constructs (Module, AddHandler, ByRef) need mapping to Java equivalents. Most have well-known patterns.');
    }

    if (inventory.databaseReferences.length > 0) {
      assessment.recommendations.push('Database access patterns should be mapped to Spring Data JPA repositories or JDBC templates.');
    }

    return assessment;
  }

  /**
   * Infer qualitative impact description based on category and severity
   */
  _inferIssueImpact(issue) {
    switch (issue.category) {
      case 'SECURITY':
        return 'Critical security vulnerability. Credentials or sensitive configuration exposed in source code.';
      case 'PLATFORM_DEPENDENCY':
        return `Platform lock-in. Component depends on ${issue.symbol || 'Windows'} APIs that are incompatible with Linux target runtime.`;
      case 'DATABASE_DEPENDENCY':
        return 'Database access pattern risk. Direct SQL string concatenation or un-abstracted driver usage complicates ORM/DAO migration.';
      case 'VBNET_CONSTRUCT':
        return `Language syntax mismatch. ${issue.symbol || 'VB.NET construct'} has no direct 1:1 keyword equivalent in Java/TypeScript.`;
      case 'EXTERNAL_DEPENDENCY':
        return 'Missing or external library dependency. Assembly must be replaced by a Maven/npm package equivalent.';
      default:
        return `Presents ${issue.severity} severity migration risk for ${issue.impactType}.`;
    }
  }

  /**
   * Generate actionable resolution advice for the detected issue
   */
  _generateSuggestedResolution(issue, targetStack) {
    const symbol = issue.symbol || issue.ruleName || '';
    
    if (issue.ruleId.startsWith('SEC-CRED')) {
      return 'Extract hardcoded connection strings into environment variables (e.g. SPRING_DATASOURCE_URL) or application.yml configuration.';
    }
    if (issue.ruleId.startsWith('DB-SQL-001')) {
      return 'Replace dynamic SQL string concatenation with parameterized queries or Spring Data JPA repository methods (@Query / Named Parameters).';
    }
    if (symbol.includes('WinForms') || symbol.includes('System.Windows.Forms') || symbol.includes('WinExe')) {
      return 'Extract core business logic out of Form handlers into headless Service classes. Recreate frontend view using Angular Reactive Forms & RxJS services.';
    }
    if (symbol.includes('MySql.Data') || symbol.includes('MySqlCommand')) {
      return 'Replace ADO.NET MySqlClient with Spring Data JPA / MySQL Connector/J dependency in Maven pom.xml.';
    }
    if (symbol.includes('ByRef')) {
      return 'Convert ByRef parameter to return value or wrap inside a Java container/DTO object.';
    }
    if (symbol.includes('Module')) {
      return 'Convert VB.NET Module into a Java final class with private constructor and static methods (@UtilityClass pattern).';
    }
    if (symbol.includes('On Error') || symbol.includes('Resume')) {
      return 'Replace legacy On Error / Resume goto statements with structured Try-Catch-Finally exception blocks.';
    }

    return `Refactor ${symbol} usage to conform to standard ${targetStack} architecture.`;
  }

  /**
   * Generate migration strategy steps
   */
  _generateMigrationStrategy(issue, targetStack) {
    switch (issue.category) {
      case 'SECURITY':
        return '1. Create application.yml / env variable.\n2. Bind config in Spring Boot @ConfigurationProperties.\n3. Remove hardcoded strings.';
      case 'PLATFORM_DEPENDENCY':
        return '1. Isolate UI/OS calls.\n2. Move business logic to Spring @Service.\n3. Implement Angular UI component for user interaction.';
      case 'DATABASE_DEPENDENCY':
        return '1. Define JPA Entity class.\n2. Create Spring Data JpaRepository interface.\n3. Replace ADO.NET DataAdapter calls with Repository invocations.';
      case 'VBNET_CONSTRUCT':
        return '1. Refactor VB.NET syntax to standard object-oriented patterns.\n2. Map constructs to Java 17+ features (Records, Static Utils, Lambdas).';
      default:
        return '1. Analyze usage in source.\n2. Replace with target platform equivalent.\n3. Verify unit tests.';
    }
  }
}

module.exports = JsonReporter;
