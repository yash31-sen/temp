const fs = require('fs');
const path = require('path');

/**
 * File utility functions for the VB.NET analyzer
 */

/**
 * Recursively discover files in a directory, respecting exclusion patterns.
 * @param {string} dirPath - Root directory to scan
 * @param {string[]} excludeDirs - Directory names to exclude
 * @returns {string[]} Array of absolute file paths
 */
function discoverFiles(dirPath, excludeDirs = ['bin', 'obj', 'node_modules', '.git', '.vs']) {
  const results = [];

  function walk(currentPath) {
    let entries;
    try {
      entries = fs.readdirSync(currentPath, { withFileTypes: true });
    } catch (err) {
      return; // skip inaccessible directories
    }

    for (const entry of entries) {
      const fullPath = path.join(currentPath, entry.name);

      if (entry.isDirectory()) {
        if (!excludeDirs.includes(entry.name.toLowerCase()) &&
            !excludeDirs.includes(entry.name)) {
          walk(fullPath);
        }
      } else if (entry.isFile()) {
        results.push(fullPath);
      }
    }
  }

  walk(dirPath);
  return results;
}

/**
 * Categorize files by their extension/purpose
 * @param {string[]} files - Array of file paths
 * @param {string} projectRoot - The project root path
 * @returns {Object} Categorized file lists
 */
function categorizeFiles(files, projectRoot) {
  const categories = {
    projectFiles: [],     // .vbproj, .sln
    sourceFiles: [],      // .vb
    configFiles: [],      // .config, .json, .xml, .settings
    sqlFiles: [],         // .sql
    dllFiles: [],         // .dll
    exeFiles: [],         // .exe
    nugetPackages: [],    // .nupkg
    otherFiles: []
  };

  for (const file of files) {
    const ext = path.extname(file).toLowerCase();
    const relPath = path.relative(projectRoot, file);

    switch (ext) {
      case '.vbproj':
        categories.projectFiles.unshift(relPath); // prioritize .vbproj at index 0
        break;
      case '.sln':
        categories.projectFiles.push(relPath);
        break;
      case '.vb':
        categories.sourceFiles.push(relPath);
        break;
      case '.config':
      case '.settings':
        categories.configFiles.push(relPath);
        break;
      case '.json':
        categories.configFiles.push(relPath);
        break;
      case '.xml':
        categories.configFiles.push(relPath);
        break;
      case '.sql':
        categories.sqlFiles.push(relPath);
        break;
      case '.dll':
        categories.dllFiles.push(relPath);
        break;
      case '.exe':
        categories.exeFiles.push(relPath);
        break;
      case '.nupkg':
        categories.nugetPackages.push(relPath);
        break;
      default:
        categories.otherFiles.push(relPath);
        break;
    }
  }

  return categories;
}

/**
 * Read a text file safely
 * @param {string} filePath - Absolute path to read
 * @returns {string|null} File contents or null on error
 */
function readFileSafe(filePath) {
  try {
    return fs.readFileSync(filePath, 'utf-8');
  } catch (err) {
    return null;
  }
}

/**
 * Check if a file exists
 * @param {string} filePath
 * @returns {boolean}
 */
function fileExists(filePath) {
  try {
    return fs.existsSync(filePath);
  } catch {
    return false;
  }
}

/**
 * Get file size in bytes
 * @param {string} filePath
 * @returns {number}
 */
function getFileSize(filePath) {
  try {
    return fs.statSync(filePath).size;
  } catch {
    return 0;
  }
}

module.exports = {
  discoverFiles,
  categorizeFiles,
  readFileSafe,
  fileExists,
  getFileSize
};
