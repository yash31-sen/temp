const chalk = require('chalk');

/**
 * Structured logger for the VB.NET analyzer
 */
class Logger {
  constructor(options = {}) {
    this.verbose = options.verbose || false;
    this.silent = options.silent || false;
  }

  info(msg) {
    if (!this.silent) {
      console.log(chalk.cyan('ℹ ') + msg);
    }
  }

  success(msg) {
    if (!this.silent) {
      console.log(chalk.green('✔ ') + msg);
    }
  }

  warn(msg) {
    if (!this.silent) {
      console.log(chalk.yellow('⚠ ') + msg);
    }
  }

  error(msg) {
    console.error(chalk.red('✖ ') + msg);
  }

  debug(msg) {
    if (this.verbose && !this.silent) {
      console.log(chalk.gray('  → ') + msg);
    }
  }

  section(title) {
    if (!this.silent) {
      console.log('');
      console.log(chalk.bold.white('━'.repeat(60)));
      console.log(chalk.bold.white(`  ${title}`));
      console.log(chalk.bold.white('━'.repeat(60)));
    }
  }

  subsection(title) {
    if (!this.silent) {
      console.log('');
      console.log(chalk.bold.cyan(`  ▸ ${title}`));
    }
  }
}

module.exports = Logger;
