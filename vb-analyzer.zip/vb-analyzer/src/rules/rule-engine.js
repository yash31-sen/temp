const fs = require('fs');
const path = require('path');

/**
 * Phase 6: Rule Engine
 * 
 * Loads and manages detection rules from JSON files.
 * Provides pattern matching, severity classification, and rule extensibility.
 * Rules can be loaded from built-in files or external directories.
 */
class RuleEngine {
  constructor(logger) {
    this.logger = logger;
    this.rules = [];
    this.ruleIndex = new Map(); // ruleId → rule for fast lookup
  }

  /**
   * Load all built-in rule files
   * @param {string} [externalRulesDir] - Optional external rules directory
   */
  loadRules(externalRulesDir = null) {
    this.logger.section('Phase 6: Rule Engine');
    
    // Load built-in rules
    const builtinDir = path.join(__dirname, '..', 'rules');
    this._loadRulesFromDir(builtinDir, 'built-in');

    // Load external rules if provided
    if (externalRulesDir && fs.existsSync(externalRulesDir)) {
      this._loadRulesFromDir(externalRulesDir, 'external');
    }

    // Build index
    for (const rule of this.rules) {
      this.ruleIndex.set(rule.ruleId, rule);
    }

    this.logger.success(`Loaded ${this.rules.length} rules (${this.ruleIndex.size} unique)`);
    
    // Log category breakdown
    const categories = {};
    for (const rule of this.rules) {
      categories[rule.category] = (categories[rule.category] || 0) + 1;
    }
    for (const [cat, count] of Object.entries(categories)) {
      this.logger.debug(`  ${cat}: ${count} rules`);
    }

    return this.rules;
  }

  /**
   * Load rules from a directory containing JSON rule files
   */
  _loadRulesFromDir(dirPath, source) {
    let files;
    try {
      files = fs.readdirSync(dirPath).filter(f => f.startsWith('rules-') && f.endsWith('.json'));
    } catch (err) {
      this.logger.warn(`Could not read rules directory: ${dirPath}`);
      return;
    }

    for (const file of files) {
      const filePath = path.join(dirPath, file);
      try {
        const content = fs.readFileSync(filePath, 'utf-8');
        const rules = JSON.parse(content);
        if (Array.isArray(rules)) {
          for (const rule of rules) {
            rule._source = source;
            rule._sourceFile = file;
            this.rules.push(rule);
          }
          this.logger.info(`Loaded ${rules.length} rules from ${file} (${source})`);
        }
      } catch (err) {
        this.logger.error(`Failed to load rules from ${file}: ${err.message}`);
      }
    }
  }

  /**
   * Get all rules
   * @returns {Object[]}
   */
  getAllRules() {
    return this.rules;
  }

  /**
   * Get rules by category
   * @param {string} category
   * @returns {Object[]}
   */
  getRulesByCategory(category) {
    return this.rules.filter(r => r.category === category);
  }

  /**
   * Get a rule by ID
   * @param {string} ruleId
   * @returns {Object|undefined}
   */
  getRule(ruleId) {
    return this.ruleIndex.get(ruleId);
  }

  /**
   * Enrich an issue with full rule information
   * @param {Object} issue - A detected issue
   * @returns {Object} Enriched issue
   */
  enrichIssue(issue) {
    const rule = this.ruleIndex.get(issue.ruleId);
    if (rule) {
      return {
        ...issue,
        ruleName: issue.ruleName || rule.name,
        ruleDescription: issue.ruleDescription || rule.description,
        migrationDifficulty: issue.migrationDifficulty || rule.migrationDifficulty,
        platform: rule.platform,
        targetPlatform: rule.targetPlatform
      };
    }
    return issue;
  }

  /**
   * Get severity priority (for sorting)
   * @param {string} severity
   * @returns {number}
   */
  static severityPriority(severity) {
    const priorities = {
      'CRITICAL': 0,
      'HIGH': 1,
      'MEDIUM': 2,
      'LOW': 3,
      'INFO': 4
    };
    return priorities[severity] ?? 5;
  }

  /**
   * Get impact priority (for sorting)
   * @param {string} impact
   * @returns {number}
   */
  static impactPriority(impact) {
    const priorities = {
      'IR_BLOCKER': 0,
      'BR_BLOCKER': 1,
      'IR_WARNING': 2,
      'BR_WARNING': 3,
      'MIGRATION_WARNING': 4,
      'NO_DIRECT_IMPACT': 5
    };
    return priorities[impact] ?? 6;
  }
}

module.exports = RuleEngine;
