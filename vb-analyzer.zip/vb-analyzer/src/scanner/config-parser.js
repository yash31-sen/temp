const fs = require('fs');
const { XMLParser } = require('fast-xml-parser');

/**
 * Parses App.config / Web.config files to extract connection strings, appSettings, etc.
 */
class ConfigParser {
  constructor(logger) {
    this.logger = logger;
    this.xmlParser = new XMLParser({
      ignoreAttributes: false,
      attributeNamePrefix: '@_',
      allowBooleanAttributes: true,
      trimValues: true
    });
  }

  /**
   * Parse a .config file
   * @param {string} configPath - Absolute path to the .config file
   * @returns {Object} Parsed configuration
   */
  parse(configPath) {
    const content = fs.readFileSync(configPath, 'utf-8');
    const parsed = this.xmlParser.parse(content);
    const configuration = parsed.configuration || {};

    return {
      filePath: configPath,
      connectionStrings: this._extractConnectionStrings(configuration),
      appSettings: this._extractAppSettings(configuration),
      startup: this._extractStartup(configuration),
      runtimeInfo: this._extractRuntime(configuration)
    };
  }

  /**
   * Extract connection strings
   */
  _extractConnectionStrings(config) {
    const connStrings = [];
    const section = config.connectionStrings;
    if (!section) return connStrings;

    const adds = this._ensureArray(section.add);
    for (const add of adds) {
      if (!add) continue;
      connStrings.push({
        name: add['@_name'] || '',
        connectionString: add['@_connectionString'] || '',
        providerName: add['@_providerName'] || ''
      });
    }

    return connStrings;
  }

  /**
   * Extract appSettings key/value pairs
   */
  _extractAppSettings(config) {
    const settings = {};
    const section = config.appSettings;
    if (!section) return settings;

    const adds = this._ensureArray(section.add);
    for (const add of adds) {
      if (!add) continue;
      const key = add['@_key'] || '';
      const value = add['@_value'] || '';
      if (key) settings[key] = value;
    }

    return settings;
  }

  /**
   * Extract startup / supported runtime info
   */
  _extractStartup(config) {
    const startup = config.startup;
    if (!startup) return null;

    const runtimes = this._ensureArray(startup.supportedRuntime);
    return runtimes.map(rt => ({
      version: rt['@_version'] || '',
      sku: rt['@_sku'] || ''
    }));
  }

  /**
   * Extract runtime binding redirects
   */
  _extractRuntime(config) {
    const runtime = config.runtime;
    if (!runtime) return null;
    // Return raw for now — can be expanded later
    return { present: true };
  }

  _ensureArray(value) {
    if (!value) return [];
    if (Array.isArray(value)) return value;
    return [value];
  }
}

module.exports = ConfigParser;
