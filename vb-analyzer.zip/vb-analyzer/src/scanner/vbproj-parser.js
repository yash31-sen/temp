const fs = require('fs');
const path = require('path');
const { XMLParser } = require('fast-xml-parser');

/**
 * Parses .vbproj files and extracts project metadata, references, compile items, etc.
 */
class VbprojParser {
  constructor(logger) {
    this.logger = logger;
    this.xmlParser = new XMLParser({
      ignoreAttributes: false,
      attributeNamePrefix: '@_',
      allowBooleanAttributes: true,
      parseAttributeValue: true,
      trimValues: true
    });
  }

  /**
   * Parse a .vbproj file and extract structured metadata
   * @param {string} vbprojPath - Absolute path to the .vbproj file
   * @returns {Object} Parsed project metadata
   */
  parse(vbprojPath) {
    const content = fs.readFileSync(vbprojPath, 'utf-8');
    const parsed = this.xmlParser.parse(content);
    const project = parsed.Project || {};

    const result = {
      filePath: vbprojPath,
      toolsVersion: project['@_ToolsVersion'] || 'unknown',
      properties: this._extractProperties(project),
      references: this._extractReferences(project),
      compileItems: this._extractCompileItems(project),
      imports: this._extractImports(project),
      configItems: this._extractNoneItems(project),
      externalAssemblies: []
    };

    // Resolve external assembly paths
    result.externalAssemblies = this._resolveExternalAssemblies(result.references, vbprojPath);

    return result;
  }

  /**
   * Extract PropertyGroup values
   */
  _extractProperties(project) {
    const props = {};
    const groups = this._ensureArray(project.PropertyGroup);

    for (const group of groups) {
      if (!group) continue;
      // Collect all non-condition properties
      for (const [key, value] of Object.entries(group)) {
        if (key.startsWith('@_')) continue;
        if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
          props[key] = String(value);
        }
      }
    }

    return props;
  }

  /**
   * Extract assembly and project references
   */
  _extractReferences(project) {
    const references = [];
    const itemGroups = this._ensureArray(project.ItemGroup);

    for (const group of itemGroups) {
      if (!group) continue;

      // Assembly References
      const refs = this._ensureArray(group.Reference);
      for (const ref of refs) {
        if (!ref) continue;
        const name = typeof ref === 'string' ? ref : (ref['@_Include'] || '');
        const hintPath = ref.HintPath || null;
        const isPrivate = ref.Private || null;

        references.push({
          type: 'assembly',
          name: name,
          hintPath: hintPath,
          isPrivate: isPrivate,
          isLocal: !!hintPath
        });
      }

      // Project References
      const projRefs = this._ensureArray(group.ProjectReference);
      for (const ref of projRefs) {
        if (!ref) continue;
        references.push({
          type: 'project',
          name: ref.Name || ref['@_Include'] || '',
          projectPath: ref['@_Include'] || '',
          projectGuid: ref.Project || ''
        });
      }
    }

    return references;
  }

  /**
   * Extract Compile items (source files)
   */
  _extractCompileItems(project) {
    const items = [];
    const itemGroups = this._ensureArray(project.ItemGroup);

    for (const group of itemGroups) {
      if (!group) continue;
      const compiles = this._ensureArray(group.Compile);
      for (const item of compiles) {
        if (!item) continue;
        const include = typeof item === 'string' ? item : (item['@_Include'] || '');
        items.push({
          path: include,
          subType: item.SubType || null,
          dependentUpon: item.DependentUpon || null
        });
      }
    }

    return items;
  }

  /**
   * Extract Import items (VB.NET namespace imports)
   */
  _extractImports(project) {
    const imports = [];
    const itemGroups = this._ensureArray(project.ItemGroup);

    for (const group of itemGroups) {
      if (!group) continue;
      const importItems = this._ensureArray(group.Import);
      for (const item of importItems) {
        if (!item) continue;
        const name = typeof item === 'string' ? item : (item['@_Include'] || '');
        if (name) imports.push(name);
      }
    }

    return imports;
  }

  /**
   * Extract None items (config files, schemas, etc.)
   */
  _extractNoneItems(project) {
    const items = [];
    const itemGroups = this._ensureArray(project.ItemGroup);

    for (const group of itemGroups) {
      if (!group) continue;
      const noneItems = this._ensureArray(group.None);
      for (const item of noneItems) {
        if (!item) continue;
        const include = typeof item === 'string' ? item : (item['@_Include'] || '');
        if (include) items.push(include);
      }
    }

    return items;
  }

  /**
   * Check if referenced DLLs actually exist on disk
   */
  _resolveExternalAssemblies(references, vbprojPath) {
    const projectDir = path.dirname(vbprojPath);
    const assemblies = [];

    for (const ref of references) {
      if (ref.type === 'assembly' && ref.hintPath) {
        const resolvedPath = path.resolve(projectDir, ref.hintPath);
        const exists = fs.existsSync(resolvedPath);
        let fileSize = 0;
        try {
          if (exists) fileSize = fs.statSync(resolvedPath).size;
        } catch {}

        assemblies.push({
          name: ref.name,
          hintPath: ref.hintPath,
          resolvedPath: resolvedPath,
          exists: exists,
          fileSize: fileSize
        });
      }
    }

    return assemblies;
  }

  /**
   * Ensure a value is always an array
   */
  _ensureArray(value) {
    if (!value) return [];
    if (Array.isArray(value)) return value;
    return [value];
  }
}

module.exports = VbprojParser;
