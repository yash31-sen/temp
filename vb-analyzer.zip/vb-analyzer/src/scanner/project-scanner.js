const fs = require('fs');
const path = require('path');
const { discoverFiles, categorizeFiles } = require('../utils/file-utils');
const VbprojParser = require('./vbproj-parser');
const ConfigParser = require('./config-parser');

/**
 * Phase 1: Project Scanner
 * 
 * Discovers all files in a VB.NET project, parses .vbproj and .config files,
 * and produces a structured project inventory.
 */
class ProjectScanner {
  constructor(logger) {
    this.logger = logger;
    this.vbprojParser = new VbprojParser(logger);
    this.configParser = new ConfigParser(logger);
  }

  /**
   * Scan a VB.NET project directory and produce an inventory
   * @param {string} projectRoot - Absolute path to the project root
   * @returns {Object} Project inventory
   */
  scan(projectRoot) {
    this.logger.section('Phase 1: Project Scanner');

    // Validate project root exists
    if (!fs.existsSync(projectRoot)) {
      throw new Error(`Project directory does not exist: ${projectRoot}`);
    }

    // Discover all files (excluding bin, obj, node_modules, etc.)
    this.logger.info(`Scanning directory: ${projectRoot}`);
    const allFiles = discoverFiles(projectRoot);
    this.logger.success(`Discovered ${allFiles.length} files`);

    // Categorize files by extension
    const categories = categorizeFiles(allFiles, projectRoot);
    this.logger.debug(`Source files: ${categories.sourceFiles.length}`);
    this.logger.debug(`Project files: ${categories.projectFiles.length}`);
    this.logger.debug(`Config files: ${categories.configFiles.length}`);
    this.logger.debug(`DLL files: ${categories.dllFiles.length}`);

    // Parse .vbproj files
    const projectMetadata = [];
    for (const projFile of categories.projectFiles) {
      if (projFile.endsWith('.vbproj')) {
        const fullPath = path.resolve(projectRoot, projFile);
        this.logger.info(`Parsing project file: ${projFile}`);
        try {
          const meta = this.vbprojParser.parse(fullPath);
          projectMetadata.push(meta);
        } catch (err) {
          this.logger.error(`Failed to parse ${projFile}: ${err.message}`);
        }
      }
    }

    // Parse config files
    const configData = [];
    for (const cfgFile of categories.configFiles) {
      if (cfgFile.endsWith('.config')) {
        const fullPath = path.resolve(projectRoot, cfgFile);
        this.logger.info(`Parsing config file: ${cfgFile}`);
        try {
          const cfg = this.configParser.parse(fullPath);
          configData.push(cfg);
        } catch (err) {
          this.logger.error(`Failed to parse ${cfgFile}: ${err.message}`);
        }
      }
    }

    // Extract project name from first .vbproj
    const projectName = this._resolveProjectName(projectMetadata, projectRoot);

    // Extract key project properties
    const primaryProject = projectMetadata[0] || {};
    const props = primaryProject.properties || {};

    // Identify database references from config
    const databaseReferences = this._extractDatabaseReferences(configData);

    // Determine framework
    const targetFramework = props.TargetFrameworkVersion || props.TargetFramework || 'unknown';
    const outputType = props.OutputType || 'unknown';

    // Resolve missing assemblies
    const missingAssemblies = (primaryProject.externalAssemblies || []).filter(a => !a.exists);

    const inventory = {
      project: projectName,
      projectRoot: projectRoot,
      targetFramework: targetFramework,
      outputType: outputType,
      rootNamespace: props.RootNamespace || '',
      assemblyName: props.AssemblyName || '',
      
      projectFiles: categories.projectFiles,
      sourceFiles: categories.sourceFiles,
      configFiles: categories.configFiles,
      sqlFiles: categories.sqlFiles,
      
      dependencies: (primaryProject.references || []).map(r => ({
        name: r.name,
        type: r.type,
        hintPath: r.hintPath || null,
        isLocal: r.isLocal || false
      })),
      
      externalAssemblies: primaryProject.externalAssemblies || [],
      missingAssemblies: missingAssemblies,
      
      imports: primaryProject.imports || [],
      compileItems: primaryProject.compileItems || [],
      
      configurationFiles: configData,
      databaseReferences: databaseReferences,
      
      summary: {
        totalFiles: allFiles.length,
        sourceFileCount: categories.sourceFiles.length,
        dllCount: categories.dllFiles.length,
        configFileCount: categories.configFiles.length,
        projectFileCount: categories.projectFiles.length,
        missingAssemblyCount: missingAssemblies.length
      }
    };

    // Log summary
    this.logger.subsection('Project Inventory Summary');
    this.logger.info(`Project: ${inventory.project}`);
    this.logger.info(`Framework: ${inventory.targetFramework}`);
    this.logger.info(`Output Type: ${inventory.outputType}`);
    this.logger.info(`Source Files: ${inventory.summary.sourceFileCount}`);
    this.logger.info(`Dependencies: ${inventory.dependencies.length}`);
    this.logger.info(`External DLLs: ${(inventory.externalAssemblies).length}`);
    if (missingAssemblies.length > 0) {
      this.logger.warn(`Missing Assemblies: ${missingAssemblies.length}`);
      for (const missing of missingAssemblies) {
        this.logger.warn(`  ✖ ${missing.name} → ${missing.hintPath}`);
      }
    }
    this.logger.info(`Database References: ${databaseReferences.length}`);

    return inventory;
  }

  /**
   * Resolve project name from vbproj or directory name
   */
  _resolveProjectName(projectMetadata, projectRoot) {
    if (projectMetadata.length > 0) {
      const props = projectMetadata[0].properties || {};
      if (props.AssemblyName) return props.AssemblyName;
      if (props.RootNamespace) return props.RootNamespace;
    }
    return path.basename(projectRoot);
  }

  /**
   * Extract database references from config data
   */
  _extractDatabaseReferences(configData) {
    const refs = [];
    for (const cfg of configData) {
      for (const cs of (cfg.connectionStrings || [])) {
        refs.push({
          name: cs.name,
          connectionString: cs.connectionString,
          providerName: cs.providerName,
          source: cfg.filePath,
          dbType: this._inferDbType(cs.connectionString, cs.providerName)
        });
      }
    }
    return refs;
  }

  /**
   * Infer database type from connection string or provider
   */
  _inferDbType(connStr, provider) {
    const combined = (connStr + ' ' + provider).toLowerCase();
    if (combined.includes('mysql')) return 'MYSQL';
    if (combined.includes('sqlclient') || combined.includes('mssql') || combined.includes('sql server')) return 'SQL_SERVER';
    if (combined.includes('oracle')) return 'ORACLE';
    if (combined.includes('npgsql') || combined.includes('postgres')) return 'POSTGRESQL';
    if (combined.includes('oledb')) return 'OLEDB';
    if (combined.includes('odbc')) return 'ODBC';
    if (combined.includes('sqlite')) return 'SQLITE';
    return 'UNKNOWN';
  }
}

module.exports = ProjectScanner;
