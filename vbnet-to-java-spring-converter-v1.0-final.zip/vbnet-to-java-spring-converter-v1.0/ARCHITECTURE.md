# Conversion architecture

## 1. Project Context Index

`project-index.json` is a query-friendly projection of canonical IR, target mappings and rule metadata. It is not a new semantic source of truth.

## 2. Planner

`planner.py` uses the internal type dependency graph and Tarjan strongly-connected components. A type dependency `A → B` means the unit containing B is scheduled before A. Cycles are converted as one unit. Nested source types are explicitly coupled so a nested Java target cannot be emitted by a competing unit.

## 3. Target Symbol Registry

Type mappings are deterministic from source namespace + configured Java base package. Nested source types map to nested Java symbols and the containing Java file. The first accepted member mapping is persisted for later contexts.

## 4. Context relevance

Priority tiers:

- 100: primary source, derived business rules
- 99: compact canonical IR facts
- 98: already-generated direct Java dependencies
- 96: directly called internal method bodies
- 84: direct source type dependencies
- 72: source project/package metadata
- 70: second-hop business method bodies
- 52: internal callers/usage

Mandatory high-priority facts are never silently removed. Optional fragments are omitted only when the token budget is exhausted and are listed in each context artifact.

## 5. Large-source strategy

If primary source exceeds the configured primary fraction, member declarations are grouped under a compact type shell. Each chunk is converted to Java fragments; a later assembly prompt creates complete target files.

## 6. Generation contract

Normal conversion returns JSON with complete files, target member mappings, unresolved semantics, assumptions and notes. Markdown parsing is not part of the protocol.

## 7. Build feedback

Maven/Gradle output is deterministic validation. Parsed diagnostics feed a focused repair context. Compiler truth outranks LLM claims about compilability.

## 8. Rule coverage and traceability

Each generated Java file records the source symbols and business rules included in its conversion contexts. Project-level rule coverage is emitted separately. This is traceability, not proof that every semantic rule is perfectly implemented; integration review and tests remain necessary.

## 9. Separation of concerns

```text
Roslyn analyzer           factual source semantics
Rule extractor            derived business interpretation
Context/planner            deterministic retrieval and ordering
LLM converter              target-language synthesis
Compiler/tests             target mechanical verification
LLM repair                 focused corrections only
Integration review         project-level consistency audit
```
