#!/usr/bin/env bash
set -euo pipefail
export PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
python3 -m compileall -q conversion_pipeline tools tests
python3 -m pytest -q
rm -rf .verify-out
python3 -m conversion_pipeline --ir sample/project.ir.json --rules sample/rules --out .verify-out --base-package com.example.demo --mode contexts --require-authoritative-ir
python3 tools/inspect_contexts.py .verify-out
echo "Verification passed."
