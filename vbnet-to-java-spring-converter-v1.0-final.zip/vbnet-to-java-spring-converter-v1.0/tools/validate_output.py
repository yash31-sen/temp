#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path


def load(p):
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("out")
    ap.add_argument("--require-build-success", action="store_true")
    args = ap.parse_args()
    root = os.path.abspath(args.out)
    errors = []
    for name in ("project-index.json", "conversion-plan.json", "target-symbol-registry.json", "target-profile.json", "conversion-state.json", "run-report.json"):
        if not os.path.isfile(os.path.join(root, name)):
            errors.append(f"missing {name}")
    if errors:
        print("INVALID:", *errors, sep="\n- ")
        return 2
    plan = load(os.path.join(root, "conversion-plan.json")).get("units", [])
    reg = load(os.path.join(root, "target-symbol-registry.json"))
    state = load(os.path.join(root, "conversion-state.json"))
    seen = set()
    for u in plan:
        uid = u.get("unit_id") or u.get("unitId")
        if not uid or uid in seen:
            errors.append(f"duplicate/missing unit id: {uid}")
        seen.add(uid)
        for dep in u.get("depends_on", []):
            if dep not in {x.get("unit_id") or x.get("unitId") for x in plan}:
                errors.append(f"unit {uid} references unknown dependency {dep}")
    target_files = {}
    for s in reg.get("symbols", []):
        src, f = s.get("source_symbol"), s.get("target_file")
        if not src or not f:
            errors.append("target symbol missing source_symbol/target_file")
        target_files.setdefault(f, []).append(src)
    java_root = os.path.join(root, "java-project")
    trace_path = os.path.join(root, "traceability.json")
    if os.path.isfile(trace_path):
        trace = load(trace_path).get("files", {})
        for rel in trace:
            if rel.startswith("/") or ".." in rel.split("/"):
                errors.append(f"unsafe trace path {rel}")
            if not os.path.isfile(os.path.join(java_root, rel.replace("/", os.sep))):
                errors.append(f"traced file missing: {rel}")
    report = load(os.path.join(root, "run-report.json"))
    if args.require_build_success:
        builds = report.get("builds", [])
        if not builds or not builds[-1].get("success"):
            errors.append("final build is not successful")
    if errors:
        print("INVALID:")
        for e in errors:
            print("-", e)
        return 2
    print(f"OK: units={len(plan)}, targetSymbols={len(reg.get('symbols', []))}, stateUnits={len(state.get('units', {}))}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
