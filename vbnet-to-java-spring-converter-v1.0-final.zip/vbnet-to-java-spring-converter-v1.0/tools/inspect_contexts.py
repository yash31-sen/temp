#!/usr/bin/env python3
from __future__ import annotations
import argparse, glob, json, os

ap=argparse.ArgumentParser(); ap.add_argument("out"); args=ap.parse_args()
rows=[]
for p in glob.glob(os.path.join(args.out,"contexts","*.json")):
    d=json.load(open(p,encoding="utf-8")); rows.append((d.get("tokenEstimate",0), os.path.basename(p), len(d.get("fragments",[])), len(d.get("omittedFragments",[]))))
print(f"contexts={len(rows)}")
for tokens,name,frags,omitted in sorted(rows, reverse=True)[:25]:
    print(f"{tokens:7d} tokens  {frags:3d} fragments  {omitted:3d} omitted  {name}")
