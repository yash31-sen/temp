from conversion_pipeline.ir_reader import CanonicalIR
from conversion_pipeline.registry import TargetSymbolRegistry


def test_type_mapping_cannot_be_overwritten(tmp_path):
    ir = CanonicalIR("sample/project.ir.json")
    p = tmp_path / "reg.json"
    reg = TargetSymbolRegistry(ir, "com.example.demo", str(p))
    sid = next(iter(ir.types_by_id))
    original = reg.for_source(sid).target_symbol
    reg.mark_generated([sid], "CU-X", [{"sourceSymbol": sid, "targetSymbol": "evil.Override", "targetFile": "x.java"}])
    assert reg.for_source(sid).target_symbol == original


def test_member_mapping_persists(tmp_path):
    ir = CanonicalIR("sample/project.ir.json")
    p = tmp_path / "reg.json"
    reg = TargetSymbolRegistry(ir, "com.example.demo", str(p))
    reg.mark_generated([], "CU-X", [{"sourceSymbol": "M:Source.Foo", "targetSymbol": "com.example.Foo.bar", "targetFile": "src/main/java/com/example/Foo.java"}])
    reg2 = TargetSymbolRegistry(ir, "com.example.demo", str(p))
    assert reg2.member_mappings["M:Source.Foo"]["targetSymbol"] == "com.example.Foo.bar"
