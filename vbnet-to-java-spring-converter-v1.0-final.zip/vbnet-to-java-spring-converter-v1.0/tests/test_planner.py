from conversion_pipeline.ir_reader import CanonicalIR
from conversion_pipeline.planner import build_conversion_plan


def test_plan_is_dependency_first():
    ir = CanonicalIR("sample/project.ir.json")
    plan = build_conversion_plan(ir)
    pos = {u.unit_id: u.order for u in plan}
    for u in plan:
        for dep in u.depends_on:
            assert pos[dep] < pos[u.unit_id]


def test_all_types_covered_once():
    ir = CanonicalIR("sample/project.ir.json")
    plan = build_conversion_plan(ir)
    seen = [t for u in plan for t in u.type_ids]
    assert sorted(seen) == sorted(ir.types_by_id)
