from conversion_pipeline.config import ContextBudget, TargetProfile
from conversion_pipeline.context_builder import ConversionContextBuilder
from conversion_pipeline.ir_reader import CanonicalIR
from conversion_pipeline.planner import build_conversion_plan
from conversion_pipeline.registry import TargetSymbolRegistry
from conversion_pipeline.rules_reader import BusinessRules


def test_context_contains_primary_and_rules(tmp_path):
    ir = CanonicalIR("sample/project.ir.json")
    rules = BusinessRules("sample/rules")
    reg = TargetSymbolRegistry(ir, "com.example.demo", str(tmp_path / "registry.json"))
    builder = ConversionContextBuilder(ir, rules, reg, TargetProfile(), ContextBudget(), str(tmp_path / "java"))
    contexts = [c for u in build_conversion_plan(ir) for c in builder.build_for_unit(u)]
    assert contexts
    assert all(c.token_estimate <= c.token_budget or any(f.priority >= 98 for f in c.fragments) for c in contexts)
    assert any(any(f.kind == "primary-source" for f in c.fragments) for c in contexts)
    assert any(c.relevant_rules for c in contexts)


def test_context_has_immutable_target_mapping(tmp_path):
    ir = CanonicalIR("sample/project.ir.json")
    reg = TargetSymbolRegistry(ir, "com.acme.migration", str(tmp_path / "registry.json"))
    unit = build_conversion_plan(ir)[0]
    ctx = ConversionContextBuilder(ir, BusinessRules(None), reg, TargetProfile(), ContextBudget()).build_for_unit(unit)[0]
    assert ctx.target_symbols
    for sid in unit.type_ids:
        assert sid in ctx.target_symbols
