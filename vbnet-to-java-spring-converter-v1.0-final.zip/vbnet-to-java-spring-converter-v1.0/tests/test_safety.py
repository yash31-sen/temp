import pytest
from conversion_pipeline.util import safe_relpath


def test_path_traversal_rejected():
    with pytest.raises(ValueError):
        safe_relpath("../../outside.java")
