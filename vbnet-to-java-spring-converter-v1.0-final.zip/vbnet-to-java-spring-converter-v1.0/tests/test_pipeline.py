import json
from conversion_pipeline.llm import MockLLMClient
from conversion_pipeline.pipeline import ConversionPipeline


def test_plan_outputs(tmp_path):
    out = tmp_path / "plan"
    p = ConversionPipeline("sample/project.ir.json", str(out), "com.example.demo", rules_dir="sample/rules")
    r = p.plan_only(write_contexts=True)
    assert r["conversionUnits"] == 3
    assert (out / "conversion-plan.json").exists()
    assert list((out / "contexts").glob("*.json"))


def test_mock_conversion_end_to_end_without_build(tmp_path):
    out = tmp_path / "convert"
    p = ConversionPipeline("sample/project.ir.json", str(out), "com.example.demo", rules_dir="sample/rules", llm=MockLLMClient())
    r = p.convert(build=False, integration_review=False)
    assert not r["failed"]
    assert r["generatedUnits"] == 3
    assert (out / "traceability.json").exists()
    assert (out / "rule-coverage.json").exists()
    assert (out / "java-project" / "src/main/java/com/example/Generated.java").exists()
