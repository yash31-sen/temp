$ErrorActionPreference = "Stop"
$env:PYTEST_DISABLE_PLUGIN_AUTOLOAD="1"
python -m compileall -q conversion_pipeline tools tests
python -m pytest -q
Remove-Item -Recurse -Force .verify-out -ErrorAction SilentlyContinue
python -m conversion_pipeline --ir sample/project.ir.json --rules sample/rules --out .verify-out --base-package com.example.demo --mode contexts --require-authoritative-ir
python tools/inspect_contexts.py .verify-out
Write-Host "Verification passed."
