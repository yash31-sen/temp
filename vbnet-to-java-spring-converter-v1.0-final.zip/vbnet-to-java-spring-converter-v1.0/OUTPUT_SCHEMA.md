# LLM conversion output contract

Full conversion response:

```json
{
  "files": [
    {
      "path": "src/main/java/com/example/Foo.java",
      "content": "complete Java source",
      "sourceSymbols": ["T:Source.Foo", "M:Source.Foo.Bar(...)"]
    }
  ],
  "symbolMappings": [
    {
      "sourceSymbol": "M:Source.Foo.Bar(System.Decimal)",
      "targetSymbol": "com.example.Foo.bar(java.math.BigDecimal)",
      "targetFile": "src/main/java/com/example/Foo.java"
    }
  ],
  "unresolved": [
    {"sourceSymbol": "...", "reason": "source dependency unavailable"}
  ],
  "assumptions": [],
  "notes": []
}
```

For oversized semantic chunks the intermediate response uses `fragments[]`; those outputs are never written directly as final Java files. They pass through the assembly stage.
