Imports System

Namespace Demo.Services
    Public Class PremiumService
        Private ReadOnly _rates As RateProvider

        Public Sub New(rates As RateProvider)
            _rates = rates
        End Sub

        Public Function CalculatePremium(productCode As String, age As Integer, sumAssured As Decimal) As Decimal
            If age < 18 OrElse age > 65 Then
                Throw New ArgumentOutOfRangeException(NameOf(age))
            End If
            Dim rate = _rates.GetRate(productCode)
            Return sumAssured / 1000D * rate
        End Function
    End Class
End Namespace
