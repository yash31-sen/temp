Namespace Demo.Domain
    Public Class Policy
        Public Property ProductCode As String
        Public Property Age As Integer
        Public Property SumAssured As Decimal
    End Class
End Namespace
