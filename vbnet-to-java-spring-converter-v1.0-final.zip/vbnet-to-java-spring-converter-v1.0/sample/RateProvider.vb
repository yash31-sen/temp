Namespace Demo.Domain
    Public Class RateProvider
        Public Function GetRate(productCode As String) As Decimal
            Select Case productCode
                Case "A"
                    Return 1.25D
                Case "B"
                    Return 1.5D
                Case Else
                    Throw New ArgumentException(productCode)
            End Select
        End Function
    End Class
End Namespace
