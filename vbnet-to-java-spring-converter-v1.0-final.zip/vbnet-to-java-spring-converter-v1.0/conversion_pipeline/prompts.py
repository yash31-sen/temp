from __future__ import annotations

import json
from typing import Any, Dict, Iterable, List

from .mappings import mapping_prompt
from .models import ConversionContext, ConversionUnit


SYSTEM = """You are a precision source-code migration engine converting VB.NET to Java/Spring.
Canonical IR and exact source code are factual. Business rules are derived intent with provenance.
Preserve observable behavior. Do not invent behavior, validation, defaults, persistence semantics,
transactions, security rules, or APIs. If semantics are unavailable, report them under `unresolved`.
Use target symbol mappings exactly when supplied. Return JSON only, with no markdown fences.
"""


def _render_context(ctx: ConversionContext) -> str:
    sections = []
    for f in ctx.fragments:
        sections.append(f"\n=== {f.kind.upper()}: {f.title} ===\n{f.content}")
    return "\n".join(sections)


def conversion_prompt(unit: ConversionUnit, ctx: ConversionContext, partial: bool = False) -> str:
    target = json.dumps(ctx.target_symbols, ensure_ascii=False, indent=2)
    profile = json.dumps(ctx.profile, ensure_ascii=False, indent=2)
    if partial:
        contract = """PARTIAL_CONVERSION
This context is one semantic chunk of an oversized conversion unit. Do not emit a complete class unless the chunk is complete.
Return exactly:
{
  "fragments": [{"targetFile":"relative/path.java","content":"Java member/type fragment","sourceSymbols":["source symbol ids"]}],
  "unresolved": [{"sourceSymbol":"...","reason":"..."}],
  "assumptions": [],
  "notes": []
}
"""
    else:
        contract = """FULL_CONVERSION
Return exactly:
{
  "files": [{"path":"src/main/java/.../Type.java","content":"complete compilable Java source","sourceSymbols":["source type/member ids"]}],
  "symbolMappings": [{"sourceSymbol":"...","targetSymbol":"fully.qualified.JavaSymbol","targetFile":"src/main/java/..."}],
  "unresolved": [{"sourceSymbol":"...","reason":"..."}],
  "assumptions": [],
  "notes": []
}
Every emitted Java file must be complete. Never use placeholders such as TODO for known source behavior.
"""
    return f"""{contract}

CONVERSION UNIT: {unit.unit_id}
SOURCE TYPES: {json.dumps(unit.type_ids)}
CYCLIC UNIT: {unit.cyclic}

TARGET PROFILE:
{profile}

TARGET SYMBOL REGISTRY (immutable for existing entries):
{target}

{mapping_prompt()}

SOURCE/DEPENDENCY CONTEXT:
{_render_context(ctx)}
"""


def assembly_prompt(unit: ConversionUnit, contexts: List[ConversionContext], partial_outputs: List[Dict[str, Any]], target_symbols: Dict[str, Any], profile: Dict[str, Any]) -> str:
    return f"""ASSEMBLE_PARTIAL_JAVA
Assemble the semantic chunk conversions into complete coherent Java source files for one conversion unit.
Resolve duplicate imports/members and preserve all source behavior represented by the chunks. Do not add new behavior.
Use the target symbol registry exactly.
Return exactly the FULL_CONVERSION JSON contract with `files`, `symbolMappings`, `unresolved`, `assumptions`, `notes`.

UNIT: {unit.unit_id}
TARGET PROFILE: {json.dumps(profile, ensure_ascii=False)}
TARGET SYMBOLS: {json.dumps(target_symbols, ensure_ascii=False, indent=2)}
PARTIAL OUTPUTS:
{json.dumps(partial_outputs, ensure_ascii=False, indent=2)}
"""


def repair_prompt(diagnostics: Dict[str, Any], files: Dict[str, str], source_context: Dict[str, Any], profile: Dict[str, Any]) -> str:
    return f"""REPAIR_JAVA
Repair only the Java files necessary to resolve the supplied compiler/test diagnostics. Preserve source semantics and business rules.
Do not perform unrelated refactors. Do not change target symbol mappings unless the mapping itself is proven inconsistent.
Return FULL_CONVERSION JSON contract. `files` should contain only files that must change.

TARGET PROFILE:
{json.dumps(profile, ensure_ascii=False, indent=2)}

DIAGNOSTICS:
{json.dumps(diagnostics, ensure_ascii=False, indent=2)}

CURRENT JAVA FILES:
{json.dumps(files, ensure_ascii=False, indent=2)}

SOURCE TRACE/CONTEXT:
{json.dumps(source_context, ensure_ascii=False, indent=2)}
"""


def integration_review_prompt(project_summary: Dict[str, Any]) -> str:
    return f"""INTEGRATION_REVIEW
Review the converted Java/Spring project at project level using the supplied compact architecture, symbol registry,
business-rule coverage, and build/test status. Do not rewrite code. Identify only concrete integration risks.
Return exactly:
{{"status":"pass|review","issues":[{{"severity":"low|medium|high","description":"...","symbols":["..."]}}],"recommendations":["..."]}}

PROJECT SUMMARY:
{json.dumps(project_summary, ensure_ascii=False, indent=2)}
"""
