from __future__ import annotations

import os
from typing import Any, Dict, Iterable, List, Optional, Set

from .util import ci_get, json_load, norm_path


class BusinessRules:
    """Reader for hierarchical rule_extractor v2 output.

    Rules are derived semantics, never authoritative source facts. The conversion
    context includes them as intent/evidence, while canonical IR remains source of truth.
    """

    def __init__(self, root: Optional[str]):
        self.root = os.path.abspath(root) if root else None
        self.rules: List[Dict[str, Any]] = []
        self.by_id: Dict[str, Dict[str, Any]] = {}
        self.by_file: Dict[str, List[Dict[str, Any]]] = {}
        self.by_symbol: Dict[str, List[Dict[str, Any]]] = {}
        if self.root:
            self._load()

    def _load(self) -> None:
        candidates = [
            os.path.join(self.root, "lineage", "all_rules.json"),
            os.path.join(self.root, "atomic", "rules.json"),
            os.path.join(self.root, "project.business-rules.json"),
        ]
        data = None
        for p in candidates:
            if os.path.isfile(p):
                try:
                    d = json_load(p)
                    if isinstance(d, dict) and isinstance(ci_get(d, "rules"), list):
                        data = d
                        if "all_rules" in p:
                            break
                except (OSError, ValueError):
                    pass
        if not data:
            return
        seen = set()
        for rule in ci_get(data, "rules", []) or []:
            rid = str(ci_get(rule, "ruleId", "") or "")
            if not rid or rid in seen:
                continue
            seen.add(rid)
            self.rules.append(rule)
            self.by_id[rid] = rule
            for sym in ci_get(rule, "relatedSymbols", []) or []:
                self.by_symbol.setdefault(str(sym), []).append(rule)
            for ev in ci_get(rule, "evidence", []) or []:
                rel = norm_path(str(ci_get(ev, "file", "") or ""))
                if rel:
                    self.by_file.setdefault(rel, []).append(rule)
                sid = str(ci_get(ev, "symbolId", "") or "")
                if sid:
                    self.by_symbol.setdefault(sid, []).append(rule)

    def relevant(self, files: Iterable[str], symbol_ids: Iterable[str], include_project: bool = False) -> List[Dict[str, Any]]:
        ids: Set[str] = set()
        for f in files:
            for r in self.by_file.get(norm_path(f), []):
                ids.add(str(ci_get(r, "ruleId", "")))
        for sid in symbol_ids:
            for r in self.by_symbol.get(sid, []):
                ids.add(str(ci_get(r, "ruleId", "")))
        if include_project:
            for r in self.rules:
                if str(ci_get(r, "level", "")) == "project":
                    ids.add(str(ci_get(r, "ruleId", "")))
        return [self.by_id[rid] for rid in sorted(ids) if rid in self.by_id]

    def compact(self, rule: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "ruleId": ci_get(rule, "ruleId"),
            "level": ci_get(rule, "level"),
            "title": ci_get(rule, "title"),
            "statement": ci_get(rule, "statement"),
            "ruleKind": ci_get(rule, "ruleKind"),
            "conditions": ci_get(rule, "conditions", []) or [],
            "outcome": ci_get(rule, "outcome"),
            "expression": ci_get(rule, "expression"),
            "confidence": ci_get(rule, "confidence"),
            "needsReview": ci_get(rule, "needsReview", False),
            "evidence": ci_get(rule, "evidence", []) or [],
        }
