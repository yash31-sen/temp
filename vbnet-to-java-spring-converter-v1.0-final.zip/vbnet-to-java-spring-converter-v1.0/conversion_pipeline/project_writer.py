from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict, Iterable, List

from .config import TargetProfile
from .util import json_dump, json_load, safe_relpath, text_write


class ProjectWriter:
    def __init__(self, root: str):
        self.root = os.path.abspath(root)
        os.makedirs(self.root, exist_ok=True)
        self.trace_path = os.path.join(os.path.dirname(self.root), "traceability.json")
        self.decisions_path = os.path.join(os.path.dirname(self.root), "decisions.json")

    def write_files(self, files: Iterable[Dict[str, Any]], unit_id: str, source_symbols: List[str], rule_ids: List[str]) -> List[str]:
        written: List[str] = []
        trace = self._load(self.trace_path, {"files": {}})
        for f in files:
            rel = safe_relpath(str(f.get("path", "")))
            if not rel.endswith(".java") and not rel.endswith(".xml") and not rel.endswith(".properties") and not rel.endswith(".yml") and not rel.endswith(".yaml"):
                raise ValueError(f"Generated path not allowed: {rel}")
            content = str(f.get("content", ""))
            dest = os.path.join(self.root, rel.replace("/", os.sep))
            text_write(dest, content)
            written.append(rel)
            file_symbols = [str(x) for x in (f.get("sourceSymbols") or [])] or list(source_symbols)
            trace["files"][rel] = {
                "conversionUnit": unit_id,
                "sourceSymbols": file_symbols,
                "businessRules": list(rule_ids),
            }
        json_dump(self.trace_path, trace)
        return written

    def append_decision(self, unit_id: str, response: Dict[str, Any]) -> None:
        d = self._load(self.decisions_path, {"units": {}})
        d["units"][unit_id] = {
            "assumptions": response.get("assumptions", []),
            "unresolved": response.get("unresolved", []),
            "notes": response.get("notes", []),
        }
        json_dump(self.decisions_path, d)

    def read_files(self, rel_paths: Iterable[str]) -> Dict[str, str]:
        out: Dict[str, str] = {}
        for rel in rel_paths:
            rel = safe_relpath(rel)
            p = os.path.join(self.root, rel.replace("/", os.sep))
            if os.path.isfile(p):
                out[rel] = Path(p).read_text(encoding="utf-8", errors="replace")
        return out

    def all_java_files(self) -> List[str]:
        result = []
        for base, _dirs, files in os.walk(self.root):
            for name in files:
                if name.endswith(".java"):
                    result.append(os.path.relpath(os.path.join(base, name), self.root).replace(os.sep, "/"))
        return sorted(result)

    def _load(self, path: str, default: Dict[str, Any]) -> Dict[str, Any]:
        try:
            v = json_load(path)
            return v if isinstance(v, dict) else default
        except (OSError, ValueError):
            return default


def ensure_maven_scaffold(java_root: str, profile: TargetProfile, artifact_id: str, base_package: str) -> None:
    pom = os.path.join(java_root, "pom.xml")
    if os.path.isfile(pom):
        return
    artifact = artifact_id.lower().replace("_", "-").replace(" ", "-")
    group = ".".join(base_package.split(".")[:-1]) or base_package
    content = f'''<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
  <modelVersion>4.0.0</modelVersion>
  <parent>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-parent</artifactId>
    <version>{profile.spring_boot_version}</version>
    <relativePath/>
  </parent>
  <groupId>{group}</groupId>
  <artifactId>{artifact}</artifactId>
  <version>0.0.1-SNAPSHOT</version>
  <properties>
    <java.version>{profile.java_version}</java.version>
  </properties>
  <dependencies>
    <dependency><groupId>org.springframework.boot</groupId><artifactId>spring-boot-starter</artifactId></dependency>
    <dependency><groupId>org.springframework.boot</groupId><artifactId>spring-boot-starter-validation</artifactId></dependency>
    <dependency><groupId>org.springframework.boot</groupId><artifactId>spring-boot-starter-data-jpa</artifactId></dependency>
    <dependency><groupId>org.springframework.boot</groupId><artifactId>spring-boot-starter-test</artifactId><scope>test</scope></dependency>
  </dependencies>
  <build><plugins><plugin><groupId>org.springframework.boot</groupId><artifactId>spring-boot-maven-plugin</artifactId></plugin></plugins></build>
</project>
'''
    text_write(pom, content)


def ensure_build_scaffold(java_root: str, profile: TargetProfile, artifact_id: str, base_package: str) -> None:
    tool = (profile.build_tool or "maven").lower()
    if tool == "maven":
        ensure_maven_scaffold(java_root, profile, artifact_id, base_package)
        return
    if tool != "gradle":
        raise ValueError(f"Unsupported build_tool: {profile.build_tool}. Use maven or gradle.")

    build = os.path.join(java_root, "build.gradle")
    if not os.path.isfile(build):
        group = ".".join(base_package.split(".")[:-1]) or base_package
        content = f"""plugins {{
    id 'java'
    id 'org.springframework.boot' version '{profile.spring_boot_version}'
    id 'io.spring.dependency-management' version '1.1.6'
}}

group = '{group}'
version = '0.0.1-SNAPSHOT'

java {{
    toolchain {{
        languageVersion = JavaLanguageVersion.of({profile.java_version})
    }}
}}

repositories {{ mavenCentral() }}

dependencies {{
    implementation 'org.springframework.boot:spring-boot-starter'
    implementation 'org.springframework.boot:spring-boot-starter-validation'
    implementation 'org.springframework.boot:spring-boot-starter-data-jpa'
    testImplementation 'org.springframework.boot:spring-boot-starter-test'
}}

tasks.named('test') {{ useJUnitPlatform() }}
"""
        text_write(build, content)
    settings = os.path.join(java_root, "settings.gradle")
    if not os.path.isfile(settings):
        artifact = artifact_id.lower().replace("_", "-").replace(" ", "-")
        text_write(settings, f"rootProject.name = '{artifact}'\n")
