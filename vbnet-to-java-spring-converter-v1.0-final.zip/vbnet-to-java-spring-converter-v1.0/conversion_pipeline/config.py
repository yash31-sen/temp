from __future__ import annotations

from dataclasses import dataclass, asdict, field
from typing import Any, Dict, List
import json


@dataclass
class ContextBudget:
    context_window_tokens: int = 64_000
    prompt_reserve_tokens: int = 6_000
    output_reserve_tokens: int = 16_000
    safety_tokens: int = 2_000
    chars_per_token: float = 3.2
    max_primary_fraction: float = 0.55

    @property
    def input_budget_tokens(self) -> int:
        return max(4_000, self.context_window_tokens - self.prompt_reserve_tokens - self.output_reserve_tokens - self.safety_tokens)

    def estimate(self, text: str) -> int:
        return max(1, int(len(text or "") / max(1.0, self.chars_per_token)))

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self) | {"input_budget_tokens": self.input_budget_tokens}


@dataclass
class TargetProfile:
    language: str = "Java"
    java_version: int = 21
    framework: str = "Spring Boot"
    spring_boot_version: str = "3.3.5"
    build_tool: str = "maven"
    architecture: str = "layered/domain-oriented"
    dependency_injection: str = "constructor"
    validation: str = "Jakarta Validation"
    persistence: str = "Spring Data JPA when source persistence semantics require it; otherwise plain domain objects"
    logging: str = "SLF4J"
    async_strategy: str = "preserve source semantics; do not introduce async unless required"
    nullability_strategy: str = "preserve source behavior; use Optional only at API boundaries where semantically appropriate"
    dto_strategy: str = "records only for immutable data carriers when source semantics permit"
    exception_strategy: str = "preserve domain exception semantics"
    transaction_strategy: str = "add @Transactional only when source unit-of-work behavior requires it"
    package_strategy: str = "preserve source namespace hierarchy below configured base package"
    additional_constraints: List[str] = field(default_factory=lambda: [
        "Use BigDecimal for System.Decimal and financial arithmetic.",
        "Do not invent business rules, validations, defaults, database behavior, or side effects.",
        "Use the target symbol registry exactly for symbols that already have mappings.",
        "If required source semantics are unavailable, report them in unresolved instead of guessing.",
        "Preserve externally observable behavior before applying stylistic modernization.",
    ])

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def load_target_profile(path: str) -> TargetProfile:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, dict):
        raise ValueError("Target profile must be a JSON object")
    allowed = set(TargetProfile.__dataclass_fields__)
    unknown = sorted(set(data) - allowed)
    if unknown:
        raise ValueError(f"Unknown target-profile keys: {unknown}")
    return TargetProfile(**data)
