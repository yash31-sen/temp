from __future__ import annotations

import json
import os
from dataclasses import asdict
from typing import Any, Dict, List, Optional

from .build_runner import run_build
from .config import ContextBudget, TargetProfile
from .context_builder import ConversionContextBuilder
from .coverage import compute_rule_coverage
from .generation import JavaGenerator
from .integration import run_integration_review
from .ir_reader import CanonicalIR
from .llm import LLMClient
from .planner import build_conversion_plan
from .project_index import build_project_index
from .project_writer import ProjectWriter, ensure_build_scaffold
from .registry import TargetSymbolRegistry
from .repair import RepairEngine
from .rules_reader import BusinessRules
from .state import ConversionState
from .util import ci_get, json_dump, slug


class ConversionPipeline:
    def __init__(
        self,
        ir_path: str,
        out_dir: str,
        base_package: str,
        rules_dir: Optional[str] = None,
        source_root: Optional[str] = None,
        llm: Optional[LLMClient] = None,
        profile: Optional[TargetProfile] = None,
        budget: Optional[ContextBudget] = None,
        require_authoritative_ir: bool = False,
    ):
        self.out = os.path.abspath(out_dir)
        os.makedirs(self.out, exist_ok=True)
        self.ir = CanonicalIR(ir_path, source_root=source_root)
        if require_authoritative_ir and not self.ir.authoritative:
            raise ValueError(f"Canonical IR is not authoritative: status={self.ir.analysis_status}")
        self.rules = BusinessRules(rules_dir)
        self.profile = profile or TargetProfile()
        self.budget = budget or ContextBudget()
        self.java_root = os.path.join(self.out, "java-project")
        os.makedirs(self.java_root, exist_ok=True)
        self.registry = TargetSymbolRegistry(self.ir, base_package, os.path.join(self.out, "target-symbol-registry.json"))
        self.registry.save()
        self.index = build_project_index(self.ir, self.rules, self.registry)
        json_dump(os.path.join(self.out, "project-index.json"), self.index)
        json_dump(os.path.join(self.out, "target-profile.json"), self.profile.to_dict())
        self.plan = build_conversion_plan(self.ir)
        json_dump(os.path.join(self.out, "conversion-plan.json"), {"units": [u.to_dict() for u in self.plan]})
        self.state = ConversionState(os.path.join(self.out, "conversion-state.json"))
        self.writer = ProjectWriter(self.java_root)
        self.llm = llm
        self.ctx_builder = ConversionContextBuilder(self.ir, self.rules, self.registry, self.profile, self.budget, generated_root=self.java_root)

    def plan_only(self, write_contexts: bool = False) -> Dict[str, Any]:
        contexts = 0
        omitted = 0
        if write_contexts:
            for unit in self.plan:
                ctxs = self.ctx_builder.build_for_unit(unit)
                contexts += len(ctxs)
                for ctx in ctxs:
                    omitted += len(ctx.omitted_fragments)
                    json_dump(os.path.join(self.out, "contexts", f"{unit.order:04d}-{ctx.context_id}.json"), ctx.to_dict(True))
        report = self._base_report()
        report.update({"mode": "plan", "contexts": contexts, "omittedFragments": omitted})
        json_dump(os.path.join(self.out, "run-report.json"), report)
        return report

    def convert(self, *, write_contexts: bool = True, resume: bool = True, build: bool = True, run_tests: bool = True, max_repairs: int = 2, integration_review: bool = True) -> Dict[str, Any]:
        if self.llm is None:
            raise ValueError("LLM client is required for conversion. Use plan/context mode for offline inspection.")
        ensure_build_scaffold(self.java_root, self.profile, self.ir.project_name, self.registry.base_package)
        generator = JavaGenerator(self.llm, max_output_tokens=self.budget.output_reserve_tokens)
        generated_units = 0
        skipped_units = 0
        failures: List[Dict[str, Any]] = []

        for unit in self.plan:
            existing = self.state.unit(unit.unit_id)
            if resume and existing.get("status") in ("generated", "compiled") and existing.get("files"):
                skipped_units += 1
                continue
            try:
                contexts = self.ctx_builder.build_for_unit(unit)
                if write_contexts:
                    for ctx in contexts:
                        json_dump(os.path.join(self.out, "contexts", f"{unit.order:04d}-{ctx.context_id}.json"), ctx.to_dict(True))
                self.state.set(unit.unit_id, "context-built", contexts=[c.context_id for c in contexts])
                response = generator.convert(unit, contexts)
                rule_ids = sorted({str(ci_get(r, "ruleId", "")) for c in contexts for r in c.relevant_rules if ci_get(r, "ruleId")})
                files = self.writer.write_files(response.get("files", []), unit.unit_id, unit.type_ids, rule_ids)
                self.writer.append_decision(unit.unit_id, response)
                self.registry.mark_generated(unit.type_ids, unit.unit_id, response.get("symbolMappings"))
                self.state.set(unit.unit_id, "generated", files=files, unresolved=response.get("unresolved", []), assumptions=response.get("assumptions", []))
                generated_units += 1
            except Exception as e:
                failures.append({"unitId": unit.unit_id, "error": str(e)})
                self.state.set(unit.unit_id, "failed", error=str(e))
                # Downstream units may depend on this one; stop rather than let the LLM invent missing target contracts.
                break

        build_results: List[Dict[str, Any]] = []
        final_build = None
        repairs = 0
        if build and not failures:
            final_build = run_build(self.java_root, tests=run_tests)
            build_results.append(final_build.to_dict()); self.state.add_build(final_build.to_dict())
            if final_build.attempted and not final_build.success:
                repairer = RepairEngine(self.llm, self.ir, self.rules, self.writer, self.profile, self.budget.output_reserve_tokens)
                for _ in range(max_repairs):
                    if not final_build.diagnostics:
                        break
                    try:
                        repair_response = repairer.repair(final_build.diagnostics)
                        repairs += 1
                    except Exception as e:
                        failures.append({"stage": "repair", "error": str(e)})
                        break
                    final_build = run_build(self.java_root, tests=run_tests)
                    build_results.append(final_build.to_dict()); self.state.add_build(final_build.to_dict())
                    if final_build.success:
                        break
            if final_build and final_build.success:
                for unit in self.plan:
                    if self.state.unit(unit.unit_id).get("status") == "generated":
                        self.registry.mark_compiled(unit.type_ids)
                        self.state.set(unit.unit_id, "compiled")

        coverage = compute_rule_coverage(self.rules, self.writer)
        json_dump(os.path.join(self.out, "rule-coverage.json"), coverage)
        summary = self._integration_summary(final_build, failures)
        summary["ruleCoverage"] = coverage
        review = run_integration_review(self.llm if integration_review else None, summary)
        json_dump(os.path.join(self.out, "integration-review.json"), review)

        report = self._base_report()
        report.update({
            "mode": "convert",
            "generatedUnits": generated_units,
            "skippedUnits": skipped_units,
            "failed": failures,
            "repairPasses": repairs,
            "builds": build_results,
            "integrationReview": review,
        })
        json_dump(os.path.join(self.out, "run-report.json"), report)
        return report

    def _base_report(self) -> Dict[str, Any]:
        return {
            "pipelineVersion": "1.0.0",
            "project": self.ir.project_name,
            "sourceIrSchemaVersion": self.ir.schema_version,
            "sourceIrAuthoritative": self.ir.authoritative,
            "compilationErrors": self.ir.compilation_errors,
            "businessRuleCount": len(self.rules.rules),
            "conversionUnits": len(self.plan),
            "contextBudget": self.budget.to_dict(),
            "javaRoot": self.java_root,
        }

    def _integration_summary(self, build_result: Any, failures: List[Dict[str, Any]]) -> Dict[str, Any]:
        return {
            "project": self.ir.project_name,
            "targetProfile": self.profile.to_dict(),
            "unitStatuses": {u.unit_id: self.state.unit(u.unit_id).get("status") for u in self.plan},
            "targetSymbols": self.registry.to_dict(),
            "businessRules": {
                "count": len(self.rules.rules),
                "projectRules": [self.rules.compact(r) for r in self.rules.rules if str(ci_get(r, "level", "")) == "project"],
            },
            "build": build_result.to_dict() if build_result else {"attempted": False},
            "pipelineFailures": failures,
            "decisionsFile": "decisions.json",
            "traceabilityFile": "traceability.json",
        }
