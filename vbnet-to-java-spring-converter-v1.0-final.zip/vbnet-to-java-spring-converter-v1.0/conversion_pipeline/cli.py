from __future__ import annotations

import argparse
import json
import os
import sys

from .config import ContextBudget, TargetProfile, load_target_profile
from .llm import MockLLMClient, OpenAICompatibleClient
from .pipeline import ConversionPipeline


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="VB.NET canonical IR -> Java/Spring migration pipeline")
    p.add_argument("--ir", required=True, help="Path to canonical project.ir.json")
    p.add_argument("--rules", help="Business-rule extractor output directory")
    p.add_argument("--source-root", help="Original VB source root, only needed if file IR does not contain RawSource")
    p.add_argument("--out", required=True, help="Conversion output directory")
    p.add_argument("--base-package", default="com.migration.application", help="Target Java base package")
    p.add_argument("--mode", choices=["plan", "contexts", "convert"], default="plan")
    p.add_argument("--require-authoritative-ir", action="store_true")
    p.add_argument("--context-window", type=int, default=64000)
    p.add_argument("--prompt-reserve", type=int, default=6000)
    p.add_argument("--output-reserve", type=int, default=16000)
    p.add_argument("--java-version", type=int, default=21)
    p.add_argument("--spring-boot-version", default="3.3.5")
    p.add_argument("--target-profile", help="Optional JSON TargetProfile override")
    p.add_argument("--no-build", action="store_true")
    p.add_argument("--no-tests", action="store_true")
    p.add_argument("--max-repairs", type=int, default=2)
    p.add_argument("--no-resume", action="store_true")
    p.add_argument("--no-integration-review", action="store_true")
    p.add_argument("--mock-llm", action="store_true", help="Testing only")
    return p


def main(argv=None) -> int:
    args = parser().parse_args(argv)
    budget = ContextBudget(args.context_window, args.prompt_reserve, args.output_reserve)
    profile = load_target_profile(args.target_profile) if args.target_profile else TargetProfile(java_version=args.java_version, spring_boot_version=args.spring_boot_version)
    llm = None
    if args.mode == "convert":
        llm = MockLLMClient() if args.mock_llm else OpenAICompatibleClient.from_env()
    try:
        pipe = ConversionPipeline(
            args.ir, args.out, args.base_package,
            rules_dir=args.rules, source_root=args.source_root, llm=llm,
            profile=profile, budget=budget, require_authoritative_ir=args.require_authoritative_ir,
        )
        if args.mode == "plan":
            report = pipe.plan_only(write_contexts=False)
        elif args.mode == "contexts":
            report = pipe.plan_only(write_contexts=True)
        else:
            report = pipe.convert(
                write_contexts=True,
                resume=not args.no_resume,
                build=not args.no_build,
                run_tests=not args.no_tests,
                max_repairs=max(0, args.max_repairs),
                integration_review=not args.no_integration_review,
            )
        print(json.dumps(report, indent=2, ensure_ascii=False))
        return 0 if not report.get("failed") else 2
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2
