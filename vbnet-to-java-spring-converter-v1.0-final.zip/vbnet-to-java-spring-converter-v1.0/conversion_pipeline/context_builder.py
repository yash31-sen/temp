from __future__ import annotations

import json
import os
from collections import defaultdict
from typing import Any, Dict, Iterable, List, Optional, Set

from .config import ContextBudget, TargetProfile
from .ir_reader import CanonicalIR
from .models import ContextFragment, ConversionContext, ConversionUnit
from .registry import TargetSymbolRegistry
from .rules_reader import BusinessRules
from .util import ci_get, stable_id, uniq


class ConversionContextBuilder:
    def __init__(
        self,
        ir: CanonicalIR,
        rules: BusinessRules,
        registry: TargetSymbolRegistry,
        target_profile: TargetProfile,
        budget: ContextBudget,
        generated_root: Optional[str] = None,
    ):
        self.ir = ir
        self.rules = rules
        self.registry = registry
        self.profile = target_profile
        self.budget = budget
        self.generated_root = generated_root

    def build_for_unit(self, unit: ConversionUnit) -> List[ConversionContext]:
        primary_sources = [(p, self.ir.source_for_file(p)) for p in unit.source_files]
        primary_tokens = sum(self.budget.estimate(src) for _, src in primary_sources)
        primary_limit = int(self.budget.input_budget_tokens * self.budget.max_primary_fraction)
        if primary_tokens > primary_limit:
            chunks = self._semantic_chunks(unit, primary_limit)
            if len(chunks) > 1:
                return [self._build_context(unit, primary_override=chunk, chunk_index=i, chunk_count=len(chunks))
                        for i, chunk in enumerate(chunks, 1)]
        return [self._build_context(unit)]

    def _primary_ir_summary(self, unit: ConversionUnit) -> str:
        out: List[Dict[str, Any]] = []
        for tid in unit.type_ids:
            t = self.ir.types_by_id.get(tid, {})
            out.append({
                "id": tid,
                "name": ci_get(t, "Name"),
                "fullName": ci_get(t, "FullName"),
                "kind": ci_get(t, "Kind"),
                "modifiers": ci_get(t, "Modifiers", []),
                "typeParameters": ci_get(t, "TypeParameters", []),
                "baseClass": ci_get(t, "BaseClass"),
                "interfaces": ci_get(t, "Interfaces", []),
                "fields": [self._compact_member(x) for x in (ci_get(t, "Fields", []) or [])],
                "properties": [self._compact_property(x) for x in (ci_get(t, "Properties", []) or [])],
                "methods": [self._compact_method(x) for x in (ci_get(t, "Methods", []) or [])],
            })
        return json.dumps(out, ensure_ascii=False, indent=2)

    def _compact_member(self, m: Dict[str, Any]) -> Dict[str, Any]:
        keys = ("Id", "Name", "Type", "ResolvedType", "Visibility", "Modifiers", "IsConst", "ConstantValue", "InitializerCode")
        return {k: ci_get(m, k) for k in keys if ci_get(m, k) not in (None, "", [])}

    def _compact_property(self, p: Dict[str, Any]) -> Dict[str, Any]:
        d = self._compact_member(p)
        for a in ("Getter", "Setter"):
            x = ci_get(p, a)
            if isinstance(x, dict):
                d[a] = {k: ci_get(x, k) for k in ("Id", "Visibility", "IsAuto", "RawCode") if ci_get(x, k) not in (None, "")}
        return d

    def _compact_method(self, m: Dict[str, Any]) -> Dict[str, Any]:
        keys = ("Id", "Name", "Kind", "Visibility", "Modifiers", "Parameters", "ReturnType", "ResolvedReturnType", "TypeParameters", "Conditions", "Throws", "IsImplicitlyDeclared")
        return {k: ci_get(m, k) for k in keys if ci_get(m, k) not in (None, "", [])}

    def _build_context(
        self,
        unit: ConversionUnit,
        primary_override: Optional[List[ContextFragment]] = None,
        chunk_index: int = 0,
        chunk_count: int = 0,
    ) -> ConversionContext:
        fragments: List[ContextFragment] = []
        if primary_override is not None:
            fragments.extend(primary_override)
        else:
            for p in unit.source_files:
                src = self.ir.source_for_file(p)
                fragments.append(self._frag("primary-source", p, src, 100, p, unit.type_ids, "target conversion unit"))
        fragments.append(self._frag("primary-ir", "Canonical IR facts", self._primary_ir_summary(unit), 99, "", unit.type_ids, "resolved source semantics"))

        unit_types = set(unit.type_ids)
        unit_files = set(unit.source_files)
        owned_symbols = {s.symbol_id for tid in unit.type_ids for s in self.ir.callables_by_type.get(tid, [])}

        # Direct called internal methods: highest-value behavioral dependencies.
        direct_called = self.ir.direct_called_symbols(unit.type_ids)
        for sid in sorted(direct_called):
            sym = self.ir.symbols.get(sid)
            if not sym or sym.owner_type_id in unit_types:
                continue
            code = sym.raw_code or self.ir.source_slice(sym.source_file, sym.span.start_line, sym.span.end_line)
            fragments.append(self._frag("called-source", sid, code, 96, sym.source_file, [sid, sym.owner_type_id], "direct internal call"))

        # Direct type dependencies. Prefer already generated Java, but retain compact source declaration as evidence.
        dep_types = self.ir.internal_type_dependencies(unit.type_ids) - unit_types
        for tid in sorted(dep_types):
            target = self.registry.for_source(tid)
            if target and target.status in ("generated", "compiled"):
                java = self._read_generated(target.target_file)
                if java:
                    fragments.append(self._frag("generated-java-dependency", target.target_symbol, java, 98, target.target_file, [tid], "already converted dependency"))
            raw = self.ir.type_raw_declaration(tid)
            if raw:
                fragments.append(self._frag("type-dependency-source", self.ir.type_full_name(tid), raw, 84, (self.ir.type_source_files(tid) or [""])[0], [tid], "direct type dependency"))

        # One additional call hop, lower priority, prevents business helper semantics from disappearing.
        second_hop: Set[str] = set()
        for sid in direct_called:
            for e in self.ir.out_calls.get(sid, []):
                if e.internal and e.resolved and e.target and e.target not in owned_symbols and e.target not in direct_called:
                    second_hop.add(e.target)
        for sid in sorted(second_hop):
            sym = self.ir.symbols.get(sid)
            if not sym:
                continue
            code = sym.raw_code or self.ir.source_slice(sym.source_file, sym.span.start_line, sym.span.end_line)
            fragments.append(self._frag("second-hop-source", sid, code, 70, sym.source_file, [sid, sym.owner_type_id], "second-hop internal call"))

        # Callers are useful for contract/usage semantics, but expendable under pressure.
        for sid in sorted(self.ir.direct_callers(unit.type_ids)):
            sym = self.ir.symbols.get(sid)
            if not sym or sym.owner_type_id in unit_types:
                continue
            code = sym.raw_code or self.ir.source_slice(sym.source_file, sym.span.start_line, sym.span.end_line)
            fragments.append(self._frag("caller-source", sid, code, 52, sym.source_file, [sid, sym.owner_type_id], "internal caller usage"))

        relevant_symbol_ids = set(unit.type_ids) | owned_symbols | direct_called | second_hop
        metadata = {
            "sourceProject": self.ir.project_name,
            "sourceTargetFramework": self.ir.target_framework,
            "packageReferences": self.ir.package_references,
            "analysisAuthoritative": self.ir.authoritative,
            "compilationErrors": self.ir.compilation_errors,
        }
        fragments.append(self._frag("source-project-metadata", "Source project metadata", json.dumps(metadata, ensure_ascii=False, indent=2), 72, "", [], "framework/package context"))
        rules = self.rules.relevant(unit_files, relevant_symbol_ids, include_project=True)
        compact_rules = [self.rules.compact(r) for r in rules]
        if compact_rules:
            fragments.append(self._frag("business-rules", "Derived business rules", json.dumps(compact_rules, ensure_ascii=False, indent=2), 100, "", sorted(relevant_symbol_ids), "LLM-derived intent with source evidence"))

        included, omitted = self._budget(fragments)
        token_est = sum(f.tokens for f in included)
        suffix = f"-chunk-{chunk_index}-of-{chunk_count}" if chunk_count else ""
        context_id = stable_id("CCTX", unit.unit_id, suffix, *(f.fragment_id for f in included))
        mapping_ids = set(unit.type_ids) | dep_types | relevant_symbol_ids
        target_symbols = self.registry.mappings_for(mapping_ids)
        return ConversionContext(
            context_id=context_id,
            unit_id=unit.unit_id,
            fragments=included,
            token_estimate=token_est,
            token_budget=self.budget.input_budget_tokens,
            omitted_fragments=omitted,
            target_symbols=target_symbols,
            relevant_rules=compact_rules,
            profile=self.profile.to_dict(),
        )

    def _read_generated(self, target_file: str) -> str:
        if not self.generated_root:
            return ""
        p = os.path.join(self.generated_root, target_file.replace("/", os.sep))
        try:
            return open(p, "r", encoding="utf-8").read() if os.path.isfile(p) else ""
        except OSError:
            return ""

    def _frag(self, kind: str, title: str, content: str, priority: int, source_file: str, symbols: Iterable[str], reason: str) -> ContextFragment:
        content = content or ""
        return ContextFragment(
            fragment_id=stable_id("CF", kind, title, source_file, content[:2000]),
            kind=kind,
            title=title,
            content=content,
            priority=priority,
            tokens=self.budget.estimate(content),
            source_file=source_file,
            symbol_ids=uniq([str(x) for x in symbols if x]),
            reason=reason,
        )

    def _budget(self, fragments: List[ContextFragment]) -> tuple[List[ContextFragment], List[ContextFragment]]:
        # Deduplicate exact fragment IDs, then mandatory facts first and score remaining by priority/tokens.
        unique: Dict[str, ContextFragment] = {f.fragment_id: f for f in fragments if f.content.strip()}
        mandatory = [f for f in unique.values() if f.priority >= 98]
        optional = [f for f in unique.values() if f.priority < 98]
        mandatory.sort(key=lambda f: (-f.priority, f.tokens, f.fragment_id))
        optional.sort(key=lambda f: (-f.priority, f.tokens, f.fragment_id))
        included: List[ContextFragment] = []
        omitted: List[ContextFragment] = []
        used = 0
        for f in mandatory:
            included.append(f)
            used += f.tokens
        for f in optional:
            if used + f.tokens <= self.budget.input_budget_tokens:
                included.append(f)
                used += f.tokens
            else:
                f.included = False
                omitted.append(f)
        return included, omitted

    def _semantic_chunks(self, unit: ConversionUnit, chunk_token_limit: int) -> List[List[ContextFragment]]:
        """Split oversized primary source by source members, never arbitrary character boundaries."""
        groups: List[List[ContextFragment]] = []
        current: List[ContextFragment] = []
        current_tokens = 0
        # Keep declaration shells so each method group knows its owner and contracts.
        for tid in unit.type_ids:
            t = self.ir.types_by_id.get(tid, {})
            shell = {
                "id": tid,
                "name": ci_get(t, "Name"), "kind": ci_get(t, "Kind"),
                "baseClass": ci_get(t, "BaseClass"), "interfaces": ci_get(t, "Interfaces", []),
                "fields": [self._compact_member(x) for x in (ci_get(t, "Fields", []) or [])],
                "properties": [self._compact_property(x) for x in (ci_get(t, "Properties", []) or [])],
            }
            shell_text = json.dumps(shell, ensure_ascii=False, indent=2)
            shell_frag = self._frag("primary-type-shell", self.ir.type_full_name(tid), shell_text, 100, (self.ir.type_source_files(tid) or [""])[0], [tid], "oversized type shell")
            members = [s for s in self.ir.callables_by_type.get(tid, []) if s.raw_code and not s.implicit]
            if not members:
                raw = self.ir.type_raw_declaration(tid)
                if raw:
                    members = []
                    f = self._frag("primary-type-source", self.ir.type_full_name(tid), raw, 100, (self.ir.type_source_files(tid) or [""])[0], [tid], "oversized type source")
                    if current and current_tokens + f.tokens > chunk_token_limit:
                        groups.append(current); current=[]; current_tokens=0
                    current.extend([shell_frag, f]); current_tokens += shell_frag.tokens + f.tokens
                continue
            for sym in members:
                f = self._frag("primary-member-source", sym.symbol_id, sym.raw_code, 100, sym.source_file, [tid, sym.symbol_id], "semantic member chunk")
                cost = f.tokens + (shell_frag.tokens if not current else 0)
                if current and current_tokens + cost > chunk_token_limit:
                    groups.append(current); current=[]; current_tokens=0
                if not current:
                    current.append(shell_frag); current_tokens += shell_frag.tokens
                current.append(f); current_tokens += f.tokens
        if current:
            groups.append(current)
        return groups or [[]]
