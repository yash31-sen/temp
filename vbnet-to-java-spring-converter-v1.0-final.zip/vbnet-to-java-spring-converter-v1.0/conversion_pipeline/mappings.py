from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List


DOTNET_TO_JAVA: Dict[str, str] = {
    "System.String": "String",
    "String": "String",
    "System.Boolean": "boolean",
    "Boolean": "boolean",
    "System.Byte": "byte",
    "Byte": "byte",
    "System.Int16": "short",
    "Short": "short",
    "System.Int32": "int",
    "Integer": "int",
    "System.Int64": "long",
    "Long": "long",
    "System.Single": "float",
    "Single": "float",
    "System.Double": "double",
    "Double": "double",
    "System.Decimal": "BigDecimal",
    "Decimal": "BigDecimal",
    "System.Guid": "UUID",
    "Guid": "UUID",
    "System.DateTime": "LocalDateTime/Instant (choose from semantics)",
    "DateTime": "LocalDateTime/Instant (choose from semantics)",
    "System.DateTimeOffset": "OffsetDateTime",
    "DateTimeOffset": "OffsetDateTime",
    "System.TimeSpan": "Duration",
    "TimeSpan": "Duration",
    "System.Object": "Object",
    "Object": "Object",
    "System.Void": "void",
    "Task": "CompletableFuture or synchronous return according to target async policy",
    "IEnumerable": "Collection/Iterable/Stream according to usage",
    "IReadOnlyCollection": "List/Collection with unmodifiable exposure when required",
    "List": "List",
    "Dictionary": "Map",
    "HashSet": "Set",
}

FRAMEWORK_GUIDANCE: List[str] = [
    "Map System.Decimal to java.math.BigDecimal and preserve scale/rounding behavior explicitly.",
    "Map Guid to java.util.UUID.",
    "Map DateTime/DateTimeOffset only after inspecting timezone semantics; do not blindly choose LocalDateTime.",
    "Map .NET collection mutability semantics deliberately; do not expose mutable collections when the source does not.",
    "Translate VB default properties/indexers to Java get/put/index access semantics, not method calls unless source semantics say method.",
    "Preserve constructor/accessor visibility. A VB Private Set must not become a public Java setter.",
    "Preserve constant values, field/property initializers, and exception behavior.",
    "Use Spring annotations only when needed by the target role; domain objects need not become Spring components.",
    "Use Spring Data repositories when the source abstraction is persistence-oriented; keep domain repository interfaces when architecture requires them.",
    "Do not silently replace source async behavior or transaction boundaries with target-framework defaults.",
]


def mapping_prompt() -> str:
    lines = ["Important .NET -> Java mappings/guidance:"]
    for src, dst in sorted(DOTNET_TO_JAVA.items()):
        lines.append(f"- {src} => {dst}")
    lines.extend(f"- {x}" for x in FRAMEWORK_GUIDANCE)
    return "\n".join(lines)
