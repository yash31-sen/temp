from __future__ import annotations

from typing import Any, Dict

from .ir_reader import CanonicalIR
from .rules_reader import BusinessRules
from .registry import TargetSymbolRegistry
from .util import ci_get


def build_project_index(ir: CanonicalIR, rules: BusinessRules, registry: TargetSymbolRegistry) -> Dict[str, Any]:
    types = []
    for tid, t in sorted(ir.types_by_id.items()):
        types.append({
            "id": tid,
            "name": ci_get(t, "Name"),
            "fullName": ci_get(t, "FullName"),
            "namespace": ci_get(t, "Namespace"),
            "kind": ci_get(t, "Kind"),
            "sourceFiles": ci_get(t, "SourceFiles", []) or [],
            "baseClass": ci_get(t, "BaseClass"),
            "interfaces": ci_get(t, "Interfaces", []) or [],
            "target": registry.for_source(tid).to_dict() if registry.for_source(tid) else None,
        })
    return {
        "indexVersion": "1.0",
        "project": {
            "name": ir.project_name,
            "sourceIrSchemaVersion": ir.schema_version,
            "targetFramework": ir.target_framework,
            "rootNamespace": ir.root_namespace,
            "authoritative": ir.authoritative,
            "compilationErrors": ir.compilation_errors,
        },
        "files": [{
            "path": p,
            "declaredTypes": [str(ci_get(t, "Id", "")) for t in ir.types_by_file.get(p, [])],
            "lines": int(ci_get(ir.file_entries[p], "Lines", 0) or 0),
            "sha256": ci_get(ir.file_entries[p], "Sha256"),
        } for p in ir.source_files()],
        "types": types,
        "graphs": {
            "typeEdges": [e.__dict__ for e in ir.type_edges],
            "callEdges": [e.__dict__ for e in ir.call_edges],
        },
        "businessRules": {
            "count": len(rules.rules),
            "levels": sorted({str(ci_get(r, "level", "")) for r in rules.rules}),
        },
        "packageReferences": ir.package_references,
        "configurationArtifacts": ir.configuration_artifacts,
    }
