from __future__ import annotations

import hashlib
import json
import os
import re
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional


def ci_get(obj: Dict[str, Any] | None, key: str, default: Any = None) -> Any:
    if not isinstance(obj, dict):
        return default
    if key in obj:
        return obj[key]
    low = key.lower()
    for k, v in obj.items():
        if str(k).lower() == low:
            return v
    return default


def as_list(value: Any) -> List[Any]:
    if value is None:
        return []
    return value if isinstance(value, list) else [value]


def norm_path(value: str) -> str:
    return (value or "").replace("\\", "/").lstrip("./")


def json_load(path: str | Path) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def json_dump(path: str | Path, data: Any) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8", newline="\n") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write("\n")
    os.replace(tmp, p)


def text_write(path: str | Path, content: str) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8", newline="\n") as f:
        f.write(content)


def stable_id(prefix: str, *parts: object, length: int = 16) -> str:
    payload = "\x1f".join(str(x) for x in parts)
    return f"{prefix}-{hashlib.sha256(payload.encode('utf-8')).hexdigest()[:length]}"


def slug(value: str, default: str = "item") -> str:
    s = re.sub(r"[^A-Za-z0-9]+", "-", value or "").strip("-").lower()
    return s or default


def java_identifier(value: str, default: str = "Generated") -> str:
    s = re.sub(r"[^A-Za-z0-9_$]", "_", value or "")
    if not s:
        s = default
    if s[0].isdigit():
        s = "_" + s
    return s


def java_package_segment(value: str) -> str:
    s = re.sub(r"[^A-Za-z0-9_]", "", (value or "").lower())
    if not s:
        s = "pkg"
    if s[0].isdigit():
        s = "p" + s
    return s


def uniq(items: Iterable[Any]) -> List[Any]:
    out: List[Any] = []
    seen = set()
    for item in items:
        marker = json.dumps(item, sort_keys=True, ensure_ascii=False) if isinstance(item, (dict, list)) else str(item)
        if marker in seen:
            continue
        seen.add(marker)
        out.append(item)
    return out


def strip_code_fence(text: str) -> str:
    t = (text or "").strip()
    if t.startswith("```"):
        lines = t.splitlines()
        if lines:
            lines = lines[1:]
        if lines and lines[-1].strip().startswith("```"):
            lines = lines[:-1]
        return "\n".join(lines).strip()
    return t


def extract_json_object(text: str) -> Dict[str, Any]:
    t = strip_code_fence(text)
    try:
        value = json.loads(t)
        if isinstance(value, dict):
            return value
    except json.JSONDecodeError:
        pass
    start = t.find("{")
    end = t.rfind("}")
    if start >= 0 and end > start:
        value = json.loads(t[start:end + 1])
        if isinstance(value, dict):
            return value
    raise ValueError("LLM response did not contain a JSON object")


def safe_relpath(path: str) -> str:
    raw = (path or "").replace("\\", "/")
    # Reject traversal/absolute paths before any normalization can erase evidence.
    if raw.startswith("/") or re.match(r"^[A-Za-z]:/", raw) or ".." in raw.split("/"):
        raise ValueError(f"Unsafe relative path: {path}")
    p = raw.lstrip("./")
    if not p:
        raise ValueError(f"Unsafe relative path: {path}")
    return p
