from __future__ import annotations

from typing import Any, Dict, List

from .llm import LLMClient
from .models import ConversionContext, ConversionUnit
from .prompts import SYSTEM, assembly_prompt, conversion_prompt


def _validate_full(data: Dict[str, Any]) -> Dict[str, Any]:
    files = data.get("files")
    if not isinstance(files, list):
        raise ValueError("Conversion response missing files[]")
    for f in files:
        if not isinstance(f, dict) or not isinstance(f.get("path"), str) or not isinstance(f.get("content"), str):
            raise ValueError("Each generated file requires path and content")
    data.setdefault("symbolMappings", [])
    data.setdefault("unresolved", [])
    data.setdefault("assumptions", [])
    data.setdefault("notes", [])
    return data


def _validate_partial(data: Dict[str, Any]) -> Dict[str, Any]:
    frags = data.get("fragments")
    if not isinstance(frags, list):
        raise ValueError("Partial conversion response missing fragments[]")
    for f in frags:
        if not isinstance(f, dict) or not isinstance(f.get("targetFile"), str) or not isinstance(f.get("content"), str):
            raise ValueError("Each partial fragment requires targetFile and content")
    data.setdefault("unresolved", [])
    data.setdefault("assumptions", [])
    data.setdefault("notes", [])
    return data


class JavaGenerator:
    def __init__(self, llm: LLMClient, max_output_tokens: int = 16000):
        self.llm = llm
        self.max_output_tokens = max_output_tokens

    def convert(self, unit: ConversionUnit, contexts: List[ConversionContext]) -> Dict[str, Any]:
        if len(contexts) == 1:
            data = self.llm.complete_json(SYSTEM, conversion_prompt(unit, contexts[0], partial=False), temperature=0.0, max_tokens=self.max_output_tokens)
            return _validate_full(data)
        partials: List[Dict[str, Any]] = []
        for ctx in contexts:
            p = self.llm.complete_json(SYSTEM, conversion_prompt(unit, ctx, partial=True), temperature=0.0, max_tokens=self.max_output_tokens)
            partials.append(_validate_partial(p))
        # Assembly input is intentionally limited to chunk outputs + immutable target/profile metadata.
        p = assembly_prompt(unit, contexts, partials, contexts[0].target_symbols, contexts[0].profile)
        data = self.llm.complete_json(SYSTEM, p, temperature=0.0, max_tokens=self.max_output_tokens)
        return _validate_full(data)
