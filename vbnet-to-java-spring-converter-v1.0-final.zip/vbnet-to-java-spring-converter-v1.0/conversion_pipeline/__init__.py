"""VB.NET canonical IR -> Java/Spring migration pipeline."""
__version__ = "1.0.0"
