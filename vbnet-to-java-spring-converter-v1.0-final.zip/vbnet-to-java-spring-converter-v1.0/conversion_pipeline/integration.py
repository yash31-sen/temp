from __future__ import annotations

from typing import Any, Dict, Optional

from .llm import LLMClient
from .prompts import SYSTEM, integration_review_prompt


def run_integration_review(llm: Optional[LLMClient], summary: Dict[str, Any], max_output_tokens: int = 6000) -> Dict[str, Any]:
    if llm is None:
        return {"status": "not-run", "issues": [], "recommendations": [], "reason": "LLM unavailable/offline"}
    data = llm.complete_json(SYSTEM, integration_review_prompt(summary), temperature=0.0, max_tokens=max_output_tokens)
    status = str(data.get("status", "review"))
    if status not in ("pass", "review"):
        status = "review"
    return {"status": status, "issues": data.get("issues", []), "recommendations": data.get("recommendations", [])}
