from __future__ import annotations

from typing import Any, Dict, List, Set

from .project_writer import ProjectWriter
from .rules_reader import BusinessRules
from .util import json_load


def compute_rule_coverage(rules: BusinessRules, writer: ProjectWriter) -> Dict[str, Any]:
    try:
        trace = json_load(writer.trace_path)
        files = trace.get("files", {}) if isinstance(trace, dict) else {}
    except (OSError, ValueError):
        files = {}
    by_rule: Dict[str, List[str]] = {}
    for rel, row in files.items():
        if not isinstance(row, dict):
            continue
        for rid in row.get("businessRules", []) or []:
            by_rule.setdefault(str(rid), []).append(rel)
    rows = []
    uncovered = []
    for r in rules.rules:
        rid = str(r.get("ruleId", ""))
        targets = sorted(set(by_rule.get(rid, [])))
        item = {"ruleId": rid, "level": r.get("level"), "targetFiles": targets, "covered": bool(targets)}
        rows.append(item)
        if not targets:
            uncovered.append(rid)
    return {
        "ruleCount": len(rows),
        "coveredCount": sum(1 for x in rows if x["covered"]),
        "uncoveredCount": len(uncovered),
        "uncoveredRuleIds": uncovered,
        "rules": rows,
    }
