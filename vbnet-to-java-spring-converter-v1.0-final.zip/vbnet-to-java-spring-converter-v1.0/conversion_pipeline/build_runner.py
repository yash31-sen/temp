from __future__ import annotations

import os
import re
import shutil
import subprocess
from typing import Any, Dict, List, Optional, Tuple

from .models import BuildResult


DIAG_PATTERNS = [
    re.compile(r"(?P<file>[A-Za-z]:\\[^\r\n:]+\.java):\[(?P<line>\d+),(?P<col>\d+)\]\s*(?P<message>.+)"),
    re.compile(r"(?P<file>[^\s:]+\.java):(?P<line>\d+):\s*(?:error:\s*)?(?P<message>.+)"),
    re.compile(r"\[(?:ERROR|WARNING)\]\s+(?P<file>[^:\r\n]+\.java):\[(?P<line>\d+),(?P<col>\d+)\]\s*(?P<message>.+)"),
]


def _tool(java_root: str) -> Tuple[str, List[str]] | None:
    if os.name == "nt" and os.path.isfile(os.path.join(java_root, "mvnw.cmd")):
        return "maven-wrapper", [os.path.join(java_root, "mvnw.cmd")]
    if os.path.isfile(os.path.join(java_root, "mvnw")):
        return "maven-wrapper", [os.path.join(java_root, "mvnw")]
    if shutil.which("mvn"):
        return "maven", [shutil.which("mvn") or "mvn"]
    if os.name == "nt" and os.path.isfile(os.path.join(java_root, "gradlew.bat")):
        return "gradle-wrapper", [os.path.join(java_root, "gradlew.bat")]
    if os.path.isfile(os.path.join(java_root, "gradlew")):
        return "gradle-wrapper", [os.path.join(java_root, "gradlew")]
    if shutil.which("gradle"):
        return "gradle", [shutil.which("gradle") or "gradle"]
    return None


def parse_diagnostics(text: str, java_root: str) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    seen = set()
    for line in (text or "").splitlines():
        for pat in DIAG_PATTERNS:
            m = pat.search(line)
            if not m:
                continue
            f = m.groupdict().get("file", "")
            try:
                rel = os.path.relpath(f, java_root).replace(os.sep, "/") if os.path.isabs(f) else f.replace("\\", "/")
            except ValueError:
                rel = f.replace("\\", "/")
            item = {
                "file": rel,
                "line": int(m.groupdict().get("line") or 0),
                "column": int(m.groupdict().get("col") or 0),
                "message": (m.groupdict().get("message") or "").strip(),
            }
            key = (item["file"], item["line"], item["column"], item["message"])
            if key not in seen:
                seen.add(key); out.append(item)
            break
    return out


def run_build(java_root: str, tests: bool = True, timeout_seconds: int = 900) -> BuildResult:
    found = _tool(java_root)
    if not found:
        return BuildResult(False, False, tool="unavailable", stderr="Neither Maven nor Gradle was found. Generated project was not compiled.")
    tool, prefix = found
    if tool.startswith("maven"):
        cmd = prefix + (["-q", "test"] if tests else ["-q", "-DskipTests", "compile"])
    else:
        cmd = prefix + (["test", "--console=plain"] if tests else ["compileJava", "--console=plain"])
    try:
        cp = subprocess.run(cmd, cwd=java_root, capture_output=True, text=True, timeout=timeout_seconds, shell=False)
        combined = (cp.stdout or "") + "\n" + (cp.stderr or "")
        return BuildResult(True, cp.returncode == 0, tool, cmd, cp.returncode, cp.stdout or "", cp.stderr or "", parse_diagnostics(combined, java_root))
    except (OSError, subprocess.TimeoutExpired) as e:
        return BuildResult(True, False, tool, cmd, None, "", str(e), [])
