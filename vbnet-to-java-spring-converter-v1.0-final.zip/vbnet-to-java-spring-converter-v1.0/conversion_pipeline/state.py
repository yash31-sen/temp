from __future__ import annotations

import os
from typing import Any, Dict

from .util import json_dump, json_load


class ConversionState:
    def __init__(self, path: str):
        self.path = path
        try:
            self.data = json_load(path) if os.path.isfile(path) else {"units": {}, "builds": []}
        except (OSError, ValueError):
            self.data = {"units": {}, "builds": []}
        self.data.setdefault("units", {})
        self.data.setdefault("builds", [])

    def unit(self, uid: str) -> Dict[str, Any]:
        return self.data["units"].setdefault(uid, {"status": "planned", "files": [], "contexts": []})

    def set(self, uid: str, status: str, **extra: Any) -> None:
        u = self.unit(uid)
        u["status"] = status
        u.update(extra)
        self.save()

    def add_build(self, result: Dict[str, Any]) -> None:
        self.data["builds"].append(result)
        self.save()

    def save(self) -> None:
        json_dump(self.path, self.data)
