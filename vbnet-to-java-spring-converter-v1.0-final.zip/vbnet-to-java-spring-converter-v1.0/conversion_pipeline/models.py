from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional


@dataclass(frozen=True)
class Span:
    start_line: int = 0
    start_column: int = 0
    end_line: int = 0
    end_column: int = 0

    def to_dict(self) -> Dict[str, int]:
        return asdict(self)


@dataclass(frozen=True)
class Symbol:
    symbol_id: str
    kind: str
    name: str
    owner_type_id: str
    source_file: str
    raw_code: str
    span: Span
    node: Dict[str, Any] = field(compare=False, hash=False, default_factory=dict)
    implicit: bool = False


@dataclass(frozen=True)
class Edge:
    source: str
    target: str
    kind: str
    source_file: str = ""
    line: int = 0
    internal: bool = False
    resolved: bool = False
    target_display: str = ""


@dataclass
class ConversionUnit:
    unit_id: str
    type_ids: List[str]
    source_files: List[str]
    depends_on: List[str] = field(default_factory=list)
    order: int = 0
    cyclic: bool = False
    status: str = "planned"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ContextFragment:
    fragment_id: str
    kind: str
    title: str
    content: str
    priority: int
    tokens: int
    source_file: str = ""
    symbol_ids: List[str] = field(default_factory=list)
    reason: str = ""
    included: bool = True

    def to_dict(self, include_content: bool = True) -> Dict[str, Any]:
        d = asdict(self)
        if not include_content:
            d.pop("content", None)
        return d


@dataclass
class ConversionContext:
    context_id: str
    unit_id: str
    fragments: List[ContextFragment]
    token_estimate: int
    token_budget: int
    omitted_fragments: List[ContextFragment] = field(default_factory=list)
    target_symbols: Dict[str, Any] = field(default_factory=dict)
    relevant_rules: List[Dict[str, Any]] = field(default_factory=list)
    profile: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self, include_content: bool = True) -> Dict[str, Any]:
        return {
            "contextId": self.context_id,
            "unitId": self.unit_id,
            "tokenEstimate": self.token_estimate,
            "tokenBudget": self.token_budget,
            "profile": self.profile,
            "targetSymbols": self.target_symbols,
            "relevantRules": self.relevant_rules,
            "fragments": [x.to_dict(include_content) for x in self.fragments],
            "omittedFragments": [x.to_dict(False) for x in self.omitted_fragments],
        }


@dataclass
class BuildResult:
    attempted: bool
    success: bool
    tool: str = ""
    command: List[str] = field(default_factory=list)
    return_code: Optional[int] = None
    stdout: str = ""
    stderr: str = ""
    diagnostics: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
