from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Set

from .models import Edge, Span, Symbol
from .util import as_list, ci_get, json_load, norm_path


class CanonicalIR:
    """Reader/index for factual VbAnalyzer schema 4.2+.

    The reader intentionally ignores any legacy `Rules` property if an older IR is
    supplied. Business semantics must come from the separate rule-extractor output.
    """

    def __init__(self, path: str, source_root: Optional[str] = None):
        self.path = os.path.abspath(path)
        self.root = os.path.dirname(self.path)
        self.data = json_load(self.path)
        self.source_root = os.path.abspath(source_root) if source_root else None

        self.schema_version = str(ci_get(self.data, "SchemaVersion", "unknown"))
        self.project_name = str(ci_get(self.data, "ProjectName", "UnknownProject"))
        self.project_file = str(ci_get(self.data, "ProjectFile", "") or "")
        self.root_namespace = str(ci_get(self.data, "RootNamespace", "") or "")
        self.target_framework = str(ci_get(self.data, "TargetFramework", "") or "")
        self.analysis_status = ci_get(self.data, "AnalysisStatus", {}) or {}
        self.files: List[Dict[str, Any]] = list(ci_get(self.data, "Files", []) or [])
        self.types: List[Dict[str, Any]] = list(ci_get(self.data, "Types", []) or [])
        self.package_references: List[Dict[str, Any]] = list(ci_get(self.data, "PackageReferences", []) or [])
        self.configuration_artifacts = list(ci_get(self.data, "ConfigurationArtifacts", []) or [])

        self.file_entries: Dict[str, Dict[str, Any]] = {}
        self.file_details: Dict[str, Dict[str, Any]] = {}
        self.types_by_id: Dict[str, Dict[str, Any]] = {}
        self.types_by_file: Dict[str, List[Dict[str, Any]]] = {}
        self.symbols: Dict[str, Symbol] = {}
        self.symbols_by_file: Dict[str, List[Symbol]] = {}
        self.callables_by_type: Dict[str, List[Symbol]] = {}
        self.call_edges: List[Edge] = []
        self.type_edges: List[Edge] = []
        self.out_calls: Dict[str, List[Edge]] = {}
        self.in_calls: Dict[str, List[Edge]] = {}
        self.out_types: Dict[str, List[Edge]] = {}
        self.in_types: Dict[str, List[Edge]] = {}
        self._build()

    @property
    def authoritative(self) -> bool:
        return bool(ci_get(self.analysis_status, "Authoritative", False))

    @property
    def compilation_errors(self) -> int:
        return int(ci_get(self.analysis_status, "CompilationErrors", 0) or 0)

    def _span(self, node: Any) -> Span:
        if not isinstance(node, dict):
            return Span()
        return Span(
            int(ci_get(node, "StartLine", 0) or 0),
            int(ci_get(node, "StartColumn", 0) or 0),
            int(ci_get(node, "EndLine", 0) or 0),
            int(ci_get(node, "EndColumn", 0) or 0),
        )

    def _build(self) -> None:
        for f in self.files:
            rel = norm_path(str(ci_get(f, "RelativePath", "") or ""))
            if not rel:
                continue
            self.file_entries[rel] = f
            detail = self._load_file_detail(f, rel)
            if detail:
                self.file_details[rel] = detail

        for t in self.types:
            tid = str(ci_get(t, "Id", "") or "")
            if not tid:
                continue
            self.types_by_id[tid] = t
            files = [norm_path(str(x)) for x in as_list(ci_get(t, "SourceFiles", [])) if x]
            for rel in files:
                self.types_by_file.setdefault(rel, []).append(t)

            for field in ci_get(t, "Fields", []) or []:
                self._add_symbol(field, "field", tid)
            for prop in ci_get(t, "Properties", []) or []:
                self._add_symbol(prop, "property", tid)
                for acc_name, kind in (("Getter", "property-getter"), ("Setter", "property-setter")):
                    acc = ci_get(prop, acc_name)
                    if isinstance(acc, dict) and ci_get(acc, "Id"):
                        merged = dict(acc)
                        merged.setdefault("Name", f"{ci_get(prop, 'Name', '')}.{acc_name.lower()}")
                        merged.setdefault("SourceFile", ci_get(prop, "SourceFile", ""))
                        self._add_symbol(merged, kind, tid, implicit=bool(ci_get(acc, "IsAuto", False)))
            for method in ci_get(t, "Methods", []) or []:
                self._add_symbol(method, "method", tid, implicit=bool(ci_get(method, "IsImplicitlyDeclared", False)))

        self.call_edges = self._parse_graph(ci_get(self.data, "CallGraph", {}) or {}, "call")
        self.type_edges = self._parse_graph(ci_get(self.data, "TypeDependencyGraph", {}) or {}, "type")
        for e in self.call_edges:
            self.out_calls.setdefault(e.source, []).append(e)
            self.in_calls.setdefault(e.target, []).append(e)
        for e in self.type_edges:
            self.out_types.setdefault(e.source, []).append(e)
            self.in_types.setdefault(e.target, []).append(e)

    def _load_file_detail(self, entry: Dict[str, Any], rel: str) -> Optional[Dict[str, Any]]:
        candidates: List[str] = []
        ir_file = str(ci_get(entry, "IrFile", "") or "")
        if ir_file:
            candidates.append(os.path.join(self.root, ir_file.replace("/", os.sep)))
        candidates.append(os.path.join(self.root, "files", (rel + ".ir.json").replace("/", os.sep)))
        for p in candidates:
            if os.path.isfile(p):
                try:
                    d = json_load(p)
                    if isinstance(d, dict):
                        return d
                except (OSError, ValueError):
                    pass
        return None

    def _add_symbol(self, node: Dict[str, Any], kind: str, owner: str, implicit: bool = False) -> None:
        sid = str(ci_get(node, "Id", "") or "")
        if not sid:
            return
        rel = norm_path(str(ci_get(node, "SourceFile", "") or ""))
        sym = Symbol(
            symbol_id=sid,
            kind=kind,
            name=str(ci_get(node, "Name", "") or ""),
            owner_type_id=owner,
            source_file=rel,
            raw_code=str(ci_get(node, "RawCode", "") or ""),
            span=self._span(ci_get(node, "SourceSpan")),
            node=node,
            implicit=implicit,
        )
        self.symbols[sid] = sym
        self.symbols_by_file.setdefault(rel, []).append(sym)
        if kind in ("method", "property-getter", "property-setter"):
            self.callables_by_type.setdefault(owner, []).append(sym)

    def _parse_graph(self, graph: Dict[str, Any], default_kind: str) -> List[Edge]:
        raw_edges = ci_get(graph, "Edges", None)
        if raw_edges is None and isinstance(graph, list):
            raw_edges = graph
        if raw_edges is None:
            raw_edges = []
        out: List[Edge] = []
        for n in raw_edges:
            if not isinstance(n, dict):
                continue
            out.append(Edge(
                source=str(ci_get(n, "From", "") or ""),
                target=str(ci_get(n, "To", "") or ""),
                kind=str(ci_get(n, "Kind", default_kind) or default_kind),
                source_file=norm_path(str(ci_get(n, "SourceFile", "") or "")),
                line=int(ci_get(n, "Line", 0) or 0),
                internal=bool(ci_get(n, "IsInternal", False)),
                resolved=bool(ci_get(n, "IsResolved", False)),
                target_display=str(ci_get(n, "TargetDisplay", "") or ""),
            ))
        return out

    def source_for_file(self, rel: str) -> str:
        rel = norm_path(rel)
        detail = self.file_details.get(rel)
        if detail:
            raw = ci_get(detail, "RawSource", "")
            if isinstance(raw, str) and raw:
                return raw
        if self.source_root:
            p = os.path.join(self.source_root, rel.replace("/", os.sep))
            if os.path.isfile(p):
                return Path(p).read_text(encoding="utf-8", errors="replace")
        # Last resort: full type declarations, preserving source order where possible.
        parts: List[tuple[int, str]] = []
        for t in self.types_by_file.get(rel, []):
            raw = str(ci_get(t, "RawDeclaration", "") or "")
            spans = as_list(ci_get(t, "DeclarationSpans", []))
            line = self._span(spans[0]).start_line if spans else 0
            if raw:
                parts.append((line, raw))
        return "\n\n".join(x[1] for x in sorted(parts))

    def source_slice(self, rel: str, start_line: int, end_line: int) -> str:
        src = self.source_for_file(rel)
        if not src:
            return ""
        lines = src.splitlines()
        s = max(1, start_line) - 1
        e = max(s + 1, min(len(lines), end_line if end_line > 0 else len(lines)))
        return "\n".join(lines[s:e])

    def source_files(self) -> List[str]:
        return sorted(self.file_entries, key=str.lower)

    def internal_type_dependencies(self, type_ids: Iterable[str]) -> Set[str]:
        out: Set[str] = set()
        for tid in type_ids:
            for e in self.out_types.get(tid, []):
                if e.internal and e.resolved and e.target:
                    out.add(e.target)
        return out

    def internal_type_dependents(self, type_ids: Iterable[str]) -> Set[str]:
        out: Set[str] = set()
        for tid in type_ids:
            for e in self.in_types.get(tid, []):
                if e.internal and e.resolved and e.source:
                    out.add(e.source)
        return out

    def direct_called_symbols(self, type_ids: Iterable[str]) -> Set[str]:
        out: Set[str] = set()
        for tid in type_ids:
            for sym in self.callables_by_type.get(tid, []):
                for e in self.out_calls.get(sym.symbol_id, []):
                    if e.internal and e.resolved and e.target:
                        out.add(e.target)
        return out

    def direct_callers(self, type_ids: Iterable[str]) -> Set[str]:
        owned = {s.symbol_id for tid in type_ids for s in self.callables_by_type.get(tid, [])}
        out: Set[str] = set()
        for sid in owned:
            for e in self.in_calls.get(sid, []):
                if e.internal and e.resolved and e.source:
                    out.add(e.source)
        return out

    def type_name(self, tid: str) -> str:
        return str(ci_get(self.types_by_id.get(tid, {}), "Name", tid) or tid)

    def type_full_name(self, tid: str) -> str:
        t = self.types_by_id.get(tid, {})
        return str(ci_get(t, "FullName", ci_get(t, "Name", tid)) or tid)

    def type_namespace(self, tid: str) -> str:
        return str(ci_get(self.types_by_id.get(tid, {}), "Namespace", "") or "")

    def type_kind(self, tid: str) -> str:
        return str(ci_get(self.types_by_id.get(tid, {}), "Kind", "Class") or "Class")

    def type_source_files(self, tid: str) -> List[str]:
        return [norm_path(str(x)) for x in as_list(ci_get(self.types_by_id.get(tid, {}), "SourceFiles", [])) if x]

    def type_raw_declaration(self, tid: str) -> str:
        return str(ci_get(self.types_by_id.get(tid, {}), "RawDeclaration", "") or "")
