from __future__ import annotations

from collections import defaultdict, deque
from typing import Dict, List, Set, Tuple

from .ir_reader import CanonicalIR
from .models import ConversionUnit
from .util import stable_id


def _tarjan(nodes: List[str], adjacency: Dict[str, Set[str]]) -> List[List[str]]:
    index = 0
    stack: List[str] = []
    on_stack: Set[str] = set()
    indices: Dict[str, int] = {}
    low: Dict[str, int] = {}
    comps: List[List[str]] = []

    def visit(v: str) -> None:
        nonlocal index
        indices[v] = low[v] = index
        index += 1
        stack.append(v)
        on_stack.add(v)
        for w in adjacency.get(v, set()):
            if w not in indices:
                visit(w)
                low[v] = min(low[v], low[w])
            elif w in on_stack:
                low[v] = min(low[v], indices[w])
        if low[v] == indices[v]:
            comp: List[str] = []
            while True:
                w = stack.pop()
                on_stack.remove(w)
                comp.append(w)
                if w == v:
                    break
            comps.append(sorted(comp))

    for n in nodes:
        if n not in indices:
            visit(n)
    return comps


def build_conversion_plan(ir: CanonicalIR) -> List[ConversionUnit]:
    nodes = sorted(ir.types_by_id)
    adj: Dict[str, Set[str]] = {n: set() for n in nodes}
    for e in ir.type_edges:
        if e.internal and e.resolved and e.source in adj and e.target in adj:
            adj[e.source].add(e.target)
    # Nested source types share one Java compilation unit with their containing type.
    # Force them into one SCC so two conversion units never overwrite the same target file.
    fulls = {tid: ir.type_full_name(tid) for tid in nodes}
    for child, child_full in fulls.items():
        for parent, parent_full in fulls.items():
            if child != parent and child_full.startswith(parent_full + "."):
                adj[child].add(parent)
                adj[parent].add(child)
    comps = _tarjan(nodes, adj)
    unit_by_type: Dict[str, str] = {}
    units: Dict[str, ConversionUnit] = {}
    for comp in comps:
        files = sorted({p for tid in comp for p in ir.type_source_files(tid)})
        uid = stable_id("CU", *comp)
        cyc = len(comp) > 1 or any(t in adj[t] for t in comp)
        unit = ConversionUnit(uid, comp, files, cyclic=cyc)
        units[uid] = unit
        for tid in comp:
            unit_by_type[tid] = uid

    # A depends on B when an edge from a type in A targets a type in B.
    for uid, unit in units.items():
        deps: Set[str] = set()
        for tid in unit.type_ids:
            for dep_tid in adj.get(tid, set()):
                dep_uid = unit_by_type.get(dep_tid)
                if dep_uid and dep_uid != uid:
                    deps.add(dep_uid)
        unit.depends_on = sorted(deps)

    # Dependency-first topological order. indegree is count of prerequisites.
    indegree = {u: len(unit.depends_on) for u, unit in units.items()}
    dependents: Dict[str, Set[str]] = defaultdict(set)
    for u, unit in units.items():
        for dep in unit.depends_on:
            dependents[dep].add(u)
    q = deque(sorted([u for u, d in indegree.items() if d == 0]))
    ordered: List[str] = []
    while q:
        u = q.popleft()
        ordered.append(u)
        for v in sorted(dependents.get(u, set())):
            indegree[v] -= 1
            if indegree[v] == 0:
                q.append(v)
    # Type graph SCC condensation must be acyclic, but be defensive.
    ordered.extend(sorted(set(units) - set(ordered)))
    result = []
    for i, uid in enumerate(ordered, 1):
        units[uid].order = i
        result.append(units[uid])
    return result
