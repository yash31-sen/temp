from __future__ import annotations

import json
import os
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Protocol

from .util import extract_json_object


class LLMClient(Protocol):
    model: str
    def complete_json(self, system: str, user: str, *, temperature: float = 0.0, max_tokens: int = 16000) -> Dict[str, Any]: ...


@dataclass
class OpenAICompatibleClient:
    base_url: str
    api_key: str
    model: str
    timeout_seconds: int = 600
    retries: int = 2

    @staticmethod
    def from_env(prefix: str = "CONVERTER_LLM_") -> "OpenAICompatibleClient":
        base = os.getenv(prefix + "BASE_URL", "http://localhost:8000/v1").rstrip("/")
        key = os.getenv(prefix + "API_KEY", "not-needed")
        model = os.getenv(prefix + "MODEL", "qwen3-coder-next-awq")
        timeout = int(os.getenv(prefix + "TIMEOUT_SECONDS", "600"))
        return OpenAICompatibleClient(base, key, model, timeout)

    def complete_json(self, system: str, user: str, *, temperature: float = 0.0, max_tokens: int = 16000) -> Dict[str, Any]:
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        body = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            self.base_url + "/chat/completions",
            data=body,
            method="POST",
            headers={"Content-Type": "application/json", "Authorization": f"Bearer {self.api_key}"},
        )
        last: Optional[Exception] = None
        for attempt in range(self.retries + 1):
            try:
                with urllib.request.urlopen(req, timeout=self.timeout_seconds) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
                content = data["choices"][0]["message"]["content"]
                return extract_json_object(content)
            except (urllib.error.URLError, urllib.error.HTTPError, KeyError, IndexError, json.JSONDecodeError, ValueError) as e:
                last = e
                if attempt < self.retries:
                    time.sleep(2 ** attempt)
        raise RuntimeError(f"LLM request failed after retries: {last}")


class MockLLMClient:
    """Deterministic test client. Not used for production conversion."""
    model = "mock"

    def __init__(self):
        self.calls: List[Dict[str, str]] = []

    def complete_json(self, system: str, user: str, *, temperature: float = 0.0, max_tokens: int = 16000) -> Dict[str, Any]:
        self.calls.append({"system": system, "user": user})
        if "ASSEMBLE_PARTIAL_JAVA" in user:
            return {
                "files": [{"path": "src/main/java/com/example/Generated.java", "content": "package com.example; public class Generated {}", "sourceSymbols": []}],
                "unresolved": [], "assumptions": [], "notes": ["mock assembly"], "symbolMappings": []
            }
        if "REPAIR_JAVA" in user:
            return {"files": [], "unresolved": [], "assumptions": [], "notes": ["mock repair"], "symbolMappings": []}
        if "INTEGRATION_REVIEW" in user:
            return {"status": "pass", "issues": [], "recommendations": []}
        if "PARTIAL_CONVERSION" in user:
            return {
                "fragments": [{"targetFile": "src/main/java/com/example/Generated.java", "content": "// mock partial", "sourceSymbols": []}],
                "unresolved": [], "assumptions": [], "notes": []
            }
        return {
            "files": [{"path": "src/main/java/com/example/Generated.java", "content": "package com.example; public class Generated {}", "sourceSymbols": []}],
            "symbolMappings": [], "unresolved": [], "assumptions": [], "notes": ["mock"]
        }
