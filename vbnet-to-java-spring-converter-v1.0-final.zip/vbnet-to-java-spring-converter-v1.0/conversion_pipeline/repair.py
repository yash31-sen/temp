from __future__ import annotations

import os
from typing import Any, Dict, List, Set

from .config import TargetProfile
from .ir_reader import CanonicalIR
from .llm import LLMClient
from .project_writer import ProjectWriter
from .prompts import SYSTEM, repair_prompt
from .rules_reader import BusinessRules
from .util import ci_get, json_load


class RepairEngine:
    def __init__(self, llm: LLMClient, ir: CanonicalIR, rules: BusinessRules, writer: ProjectWriter, profile: TargetProfile, max_output_tokens: int = 16000):
        self.llm = llm
        self.ir = ir
        self.rules = rules
        self.writer = writer
        self.profile = profile
        self.max_output_tokens = max_output_tokens

    def repair(self, diagnostics: List[Dict[str, Any]]) -> Dict[str, Any]:
        affected = sorted({str(d.get("file", "")) for d in diagnostics if str(d.get("file", "")).endswith(".java")})
        current = self.writer.read_files(affected)
        trace = self._trace_for(affected)
        source_symbols: Set[str] = set()
        rule_ids: Set[str] = set()
        for row in trace.values():
            source_symbols.update(row.get("sourceSymbols", []))
            rule_ids.update(row.get("businessRules", []))
        source_context = {
            "traceability": trace,
            "source": self._source_for_symbols(source_symbols),
            "businessRules": [self.rules.by_id[r] for r in sorted(rule_ids) if r in self.rules.by_id],
        }
        payload = {"diagnostics": diagnostics}
        response = self.llm.complete_json(
            SYSTEM,
            repair_prompt(payload, current, source_context, self.profile.to_dict()),
            temperature=0.0,
            max_tokens=self.max_output_tokens,
        )
        files = response.get("files")
        if not isinstance(files, list):
            raise ValueError("Repair response missing files[]")
        # Repair writes do not alter source mapping; preserve existing traceability.
        for f in files:
            if not isinstance(f, dict) or not isinstance(f.get("path"), str) or not isinstance(f.get("content"), str):
                raise ValueError("Invalid repair file entry")
        self.writer.write_files(files, "repair", sorted(source_symbols), sorted(rule_ids))
        return response

    def _trace_for(self, files: List[str]) -> Dict[str, Any]:
        try:
            data = json_load(self.writer.trace_path)
            all_files = data.get("files", {}) if isinstance(data, dict) else {}
        except (OSError, ValueError):
            all_files = {}
        return {f: all_files.get(f, {}) for f in files}

    def _source_for_symbols(self, symbols: Set[str]) -> Dict[str, Any]:
        result: Dict[str, Any] = {}
        for sid in sorted(symbols):
            if sid in self.ir.types_by_id:
                result[sid] = {
                    "kind": "type",
                    "fullName": self.ir.type_full_name(sid),
                    "sourceFiles": self.ir.type_source_files(sid),
                    "rawDeclaration": self.ir.type_raw_declaration(sid),
                }
            elif sid in self.ir.symbols:
                s = self.ir.symbols[sid]
                result[sid] = {
                    "kind": s.kind,
                    "sourceFile": s.source_file,
                    "rawCode": s.raw_code,
                    "span": s.span.to_dict(),
                }
        return result
