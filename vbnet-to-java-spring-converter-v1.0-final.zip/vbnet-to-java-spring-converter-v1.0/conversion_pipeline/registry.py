from __future__ import annotations

import os
import re
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from .ir_reader import CanonicalIR
from .util import ci_get, java_identifier, java_package_segment, json_dump, json_load, norm_path


@dataclass
class TargetSymbol:
    source_symbol: str
    source_full_name: str
    target_symbol: str
    target_package: str
    target_simple_name: str
    target_file: str
    kind: str
    status: str = "planned"
    generated_by_unit: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class TargetSymbolRegistry:
    def __init__(self, ir: CanonicalIR, base_package: str, path: Optional[str] = None):
        self.ir = ir
        self.base_package = ".".join(java_package_segment(x) for x in base_package.split(".") if x)
        self.path = path
        self.symbols: Dict[str, TargetSymbol] = {}
        self.member_mappings: Dict[str, Dict[str, Any]] = {}
        if path and os.path.isfile(path):
            self._load(path)
        self._ensure_types()

    def _load(self, path: str) -> None:
        data = json_load(path)
        for row in data.get("symbols", []):
            try:
                sym = TargetSymbol(**row)
                self.symbols[sym.source_symbol] = sym
            except TypeError:
                continue
        for row in data.get("memberMappings", []):
            if isinstance(row, dict) and row.get("sourceSymbol"):
                self.member_mappings[str(row["sourceSymbol"])] = dict(row)

    def _simple_name(self, raw: str) -> str:
        raw = re.sub(r"\(Of.*\)$", "", raw or "")
        raw = raw.split("`", 1)[0]
        return java_identifier(raw, "GeneratedType")

    def _package_for(self, namespace: str) -> str:
        ns = namespace or ""
        root = self.ir.root_namespace or ""
        if root and (ns == root or ns.startswith(root + ".")):
            ns = ns[len(root):].lstrip(".")
        suffix = ".".join(java_package_segment(x) for x in ns.split(".") if x)
        return self.base_package + (("." + suffix) if suffix else "")

    def _ensure_types(self) -> None:
        # Detect nested types by longest containing source full-name prefix.
        fulls = {tid: self.ir.type_full_name(tid) for tid in self.ir.types_by_id}
        for tid in sorted(self.ir.types_by_id):
            if tid in self.symbols:
                continue
            t = self.ir.types_by_id[tid]
            full = fulls[tid]
            name = self._simple_name(str(ci_get(t, "Name", "GeneratedType") or "GeneratedType"))
            ns = self.ir.type_namespace(tid)
            package = self._package_for(ns)
            parent_tid = None
            parent_len = -1
            for other, other_full in fulls.items():
                if other == tid:
                    continue
                if full.startswith(other_full + ".") and len(other_full) > parent_len:
                    parent_tid, parent_len = other, len(other_full)
            if parent_tid:
                parent = self.symbols.get(parent_tid)
                if parent is None:
                    # parent will be created deterministically on a second pass; use its expected mapping now
                    pt = self.ir.types_by_id[parent_tid]
                    ppackage = self._package_for(self.ir.type_namespace(parent_tid))
                    pname = self._simple_name(str(ci_get(pt, "Name", "Parent") or "Parent"))
                    target_symbol = f"{ppackage}.{pname}.{name}"
                    target_file = f"src/main/java/{ppackage.replace('.', '/')}/{pname}.java"
                else:
                    target_symbol = f"{parent.target_symbol}.{name}"
                    target_file = parent.target_file
            else:
                target_symbol = f"{package}.{name}"
                target_file = f"src/main/java/{package.replace('.', '/')}/{name}.java"
            self.symbols[tid] = TargetSymbol(
                source_symbol=tid,
                source_full_name=full,
                target_symbol=target_symbol,
                target_package=package,
                target_simple_name=name,
                target_file=target_file,
                kind=self.ir.type_kind(tid),
            )

    def for_source(self, sid: str) -> Optional[TargetSymbol]:
        return self.symbols.get(sid)

    def for_sources(self, sids: Iterable[str]) -> List[TargetSymbol]:
        return [self.symbols[s] for s in sids if s in self.symbols]

    def mark_generated(self, source_symbols: Iterable[str], unit_id: str, mappings: Optional[List[Dict[str, Any]]] = None) -> None:
        # LLM may add member mappings, but type mappings are immutable once planned.
        for sid in source_symbols:
            if sid in self.symbols:
                self.symbols[sid].status = "generated"
                self.symbols[sid].generated_by_unit = unit_id
        if mappings:
            # Deliberately do not let the LLM overwrite planned type destinations.
            # New member-level mappings are persisted for downstream consistency.
            for row in mappings:
                if not isinstance(row, dict):
                    continue
                source = str(row.get("sourceSymbol", "") or "")
                target = str(row.get("targetSymbol", "") or "")
                if not source or not target or source in self.symbols:
                    continue
                existing = self.member_mappings.get(source)
                if existing and existing.get("targetSymbol") != target:
                    # First accepted mapping wins; conflict remains visible to integration review.
                    continue
                clean = {
                    "sourceSymbol": source,
                    "targetSymbol": target,
                    "targetFile": str(row.get("targetFile", "") or ""),
                    "status": "generated",
                    "generatedByUnit": unit_id,
                }
                self.member_mappings[source] = clean
        self.save()

    def mark_compiled(self, source_symbols: Iterable[str]) -> None:
        for sid in source_symbols:
            if sid in self.symbols:
                self.symbols[sid].status = "compiled"
        self.save()

    def mappings_for(self, source_ids: Iterable[str]) -> Dict[str, Any]:
        out: Dict[str, Any] = {}
        for sid in source_ids:
            if sid in self.symbols:
                out[sid] = self.symbols[sid].to_dict()
            elif sid in self.member_mappings:
                out[sid] = dict(self.member_mappings[sid])
        return out

    def to_dict(self) -> Dict[str, Any]:
        return {
            "basePackage": self.base_package,
            "symbols": [self.symbols[k].to_dict() for k in sorted(self.symbols)],
            "memberMappings": [self.member_mappings[k] for k in sorted(self.member_mappings)],
        }

    def save(self, path: Optional[str] = None) -> None:
        p = path or self.path
        if p:
            json_dump(p, self.to_dict())
