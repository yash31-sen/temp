# VB.NET → Java/Spring Conversion Pipeline v1.0

This package is the next stage after:

1. **VbAnalyzer Precise Generic IR v4.2+** — deterministic/factual Roslyn IR.
2. **Hierarchical Business Rule Extractor v2.0+** — LLM-derived rules with source evidence.

It does **not** parse VB.NET itself and does **not** regenerate business rules. It consumes those two outputs and manages conversion to Java/Spring with dependency-aware context, stable symbol mappings, build/test feedback, repair passes, and traceability.

## End-to-end architecture

```text
VB.NET source
    ↓
Roslyn analyzer
    ↓
Canonical factual IR ───────────────┐
    ↓                               │
Business-rule extractor             │
    ↓                               │
Derived rules + evidence ───────────┤
                                    ↓
                           Project Context Index
                                    ↓
                           Conversion Planner
                         (SCC/dependency order)
                                    ↓
                           Target Symbol Registry
                                    ↓
                         Conversion Context Builder
                  target source + relevant dependencies
                  + rules + already-generated Java
                                    ↓
                       64K token-budget controller
                         ↓                     ↓
                    normal unit           oversized unit
                         ↓               semantic chunks
                       LLM                    ↓
                         ↓                  LLM fragments
                         │                    ↓
                         │               assembly LLM
                         └──────────┬─────────┘
                                    ↓
                           Java/Spring files
                                    ↓
                         Maven/Gradle test/compile
                         ↓                    ↓
                       PASS                  FAIL
                         ↓                    ↓
                 integration review      repair context
                                              ↓
                                             LLM
                                              ↓
                                         build again
```

## Design rules

- Canonical IR remains the source of truth for source-code facts.
- Business rules are separate derived intent and retain source evidence.
- Dependencies are selected deterministically from IR graphs; the LLM does not guess the dependency graph.
- Existing target symbol mappings are immutable. Once `Basket` becomes a particular Java symbol, later calls must use it.
- `System.Decimal`/VB `Decimal` is mapped to `BigDecimal` guidance, not `double`.
- The LLM must return unresolved semantics instead of silently inventing behavior.
- Large source units are semantically chunked by Roslyn members, not arbitrary text boundaries.
- Generated paths are sandboxed to the Java project root; path traversal is rejected.
- Compiler/test diagnostics create focused repair contexts rather than resending the whole project.

## Requirements

- Python 3.10+
- For real LLM conversion: an OpenAI-compatible chat-completions endpoint (Qwen/vLLM is supported)
- Java 21 by default (configurable)
- Maven or Gradle for automatic compile/test. If neither is installed, generation still completes and build status is reported as unavailable.

Runtime Python code uses only the standard library. `pytest` is required only for tests.

## Input expectations

### Canonical IR

Use an analyzer output directory containing:

```text
output/
  project.ir.json
  files/**/*.ir.json
  types/*.type.ir.json
```

For production conversion, use schema 4.2+ and run with `--require-authoritative-ir`.

### Business rules

Point `--rules` to the hierarchical extractor output root, for example:

```text
business-rules/
  lineage/all_rules.json
  atomic/
  files/
  components/
  project.business-rules.json
```

Rules are optional technically, but strongly recommended for migration fidelity.

## Step 1 — Build and inspect contexts before spending LLM calls

```powershell
python -m conversion_pipeline `
  --ir "C:\migration\ir\project.ir.json" `
  --rules "C:\migration\business-rules" `
  --out "C:\migration\conversion" `
  --base-package "com.mycompany.application" `
  --mode contexts `
  --require-authoritative-ir
```

Inspect context sizes:

```powershell
python tools\inspect_contexts.py "C:\migration\conversion"
```

Important outputs at this stage:

```text
project-index.json
target-profile.json
target-symbol-registry.json
conversion-plan.json
contexts/*.json
```

No LLM call is made in `plan` or `contexts` mode.

## Step 2 — Configure the LLM

For an OpenAI-compatible Qwen/vLLM endpoint:

```powershell
$env:CONVERTER_LLM_BASE_URL="http://localhost:8000/v1"
$env:CONVERTER_LLM_API_KEY="not-needed"
$env:CONVERTER_LLM_MODEL="qwen3-coder-next-awq"
$env:CONVERTER_LLM_TIMEOUT_SECONDS="600"
```

The endpoint must support `/v1/chat/completions`-style requests.

## Step 3 — Convert to Java/Spring

```powershell
python -m conversion_pipeline `
  --ir "C:\migration\ir\project.ir.json" `
  --rules "C:\migration\business-rules" `
  --out "C:\migration\conversion" `
  --base-package "com.mycompany.application" `
  --mode convert `
  --require-authoritative-ir
```

The pipeline will:

1. build/resume the conversion plan;
2. create a context for each dependency-ordered unit;
3. convert it using the LLM;
4. persist target type/member mappings;
5. write Java files;
6. create a Maven/Gradle scaffold if absent;
7. run compile/tests when the build tool is available;
8. run focused repair passes for parsed diagnostics;
9. compute business-rule trace coverage;
10. run a compact project-level integration review.

## Context budget

Default 64K configuration:

```text
model context         64,000
prompt reserve         6,000
output reserve        16,000
safety reserve         2,000
--------------------------------
input context budget  40,000 estimated tokens
```

Change it without changing the architecture:

```powershell
--context-window 128000 --output-reserve 24000
```

Token estimates intentionally use a conservative character estimator and are model-independent. If later you adopt an exact tokenizer, replace the estimator in `config.py` without changing the context-selection design.

## Oversized code

If the primary source would occupy too much of the input budget, the builder switches to semantic chunk mode:

```text
large class
   ↓
member-based chunks
   ↓
LLM Java fragments
   ↓
assembly LLM
   ↓
complete Java compilation unit
```

The source is never silently truncated.

## Target profile

Defaults are in `TargetProfile` and may be replaced with JSON:

```powershell
python -m conversion_pipeline ... `
  --target-profile target-profile.example.json
```

Important decisions are project-wide: Java version, Spring Boot version, persistence strategy, constructor injection, nullability, async policy, exception policy, and transaction policy.

The bundled Spring Boot version is a configurable default, not an assertion that it is the latest available release.

## Resume behavior

`conversion-state.json` records each unit:

```text
planned → context-built → generated → compiled
                         ↘ failed
```

A rerun resumes successful generated/compiled units by default. Use `--no-resume` to force regeneration.

## Target symbol registry

`target-symbol-registry.json` prevents cross-call inconsistency.

Type destinations are planned deterministically and cannot be overwritten by the LLM. LLM-produced member mappings are accepted once and reused downstream; conflicting later suggestions do not silently replace the first accepted mapping.

## Outputs

```text
conversion/
  project-index.json
  conversion-plan.json
  target-profile.json
  target-symbol-registry.json
  conversion-state.json
  contexts/
  java-project/
    pom.xml or build.gradle
    src/main/java/...
  traceability.json
  decisions.json
  rule-coverage.json
  integration-review.json
  run-report.json
```

`traceability.json` links generated Java files back to source symbols and derived business rules.

`decisions.json` records LLM assumptions/unresolved items. Unresolved semantics are never silently converted into facts.

## Build/repair behavior

Build tool priority:

1. `mvnw` / `mvnw.cmd`
2. installed `mvn`
3. `gradlew` / `gradlew.bat`
4. installed `gradle`

On failure, parsed Java diagnostics are matched to generated files. The repair context contains only:

- failing Java files;
- relevant diagnostics;
- source symbols traced to those files;
- original VB snippets/declarations;
- associated business rules.

The repair LLM is explicitly instructed not to perform unrelated refactoring.

## Validation

Run tests:

```powershell
$env:PYTEST_DISABLE_PLUGIN_AUTOLOAD="1"
python -m pytest -q
```

Validate a conversion output:

```powershell
python tools\validate_output.py "C:\migration\conversion"
```

Require a successful build:

```powershell
python tools\validate_output.py "C:\migration\conversion" --require-build-success
```

## Useful CLI modes

```text
--mode plan       build index/plan/registry only
--mode contexts   also materialize all LLM context packs; no LLM call
--mode convert    perform conversion and optional build/repair/review

--no-build
--no-tests
--max-repairs 2
--no-resume
--no-integration-review
--require-authoritative-ir
```

## Production recommendation

Do not begin a production Java migration from a partial canonical IR. The preferred gate is:

```text
SemanticCompilation = Complete
TypeDependencyGraph = Complete
CallGraph = Complete
CompilationErrors = 0
Authoritative = true
```

Then extract business rules, inspect conversion contexts, and only then run conversion.
