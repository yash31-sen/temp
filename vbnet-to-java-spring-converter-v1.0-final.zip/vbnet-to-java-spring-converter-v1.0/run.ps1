param(
  [Parameter(Mandatory=$true)][string]$Ir,
  [Parameter(Mandatory=$true)][string]$Out,
  [string]$Rules = "",
  [string]$BasePackage = "com.migration.application",
  [ValidateSet("plan","contexts","convert")][string]$Mode = "contexts",
  [switch]$RequireAuthoritative
)
$cmd = @("-m","conversion_pipeline","--ir",$Ir,"--out",$Out,"--base-package",$BasePackage,"--mode",$Mode)
if ($Rules) { $cmd += @("--rules",$Rules) }
if ($RequireAuthoritative) { $cmd += "--require-authoritative-ir" }
python @cmd
exit $LASTEXITCODE
