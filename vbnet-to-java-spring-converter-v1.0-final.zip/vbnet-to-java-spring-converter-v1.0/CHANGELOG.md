# Changelog

## 1.0.0

- Canonical IR 4.2-compatible project reader; legacy `Rules` fields ignored.
- Hierarchical business-rule v2 reader with evidence linkage.
- Queryable project context index.
- SCC/dependency-aware conversion planning.
- Nested-type conversion clustering.
- Immutable target type registry + persistent member mapping registry.
- Java/Spring target profile and .NET mapping guidance.
- 64K-aware deterministic context builder.
- Direct-call, second-hop, type dependency, caller, rule and generated-Java context.
- Semantic chunking for oversized source units + LLM assembly stage.
- OpenAI-compatible/Qwen client.
- JSON-only conversion protocol.
- Safe generated-file writer and traceability store.
- Resume state and decision log.
- Maven/Gradle project scaffolds.
- Maven/Gradle compile/test runner and diagnostic parser.
- Focused LLM repair pipeline.
- Business-rule coverage report.
- Project integration review.
- Windows/Linux runner scripts, validation tools, synthetic sample and tests.
